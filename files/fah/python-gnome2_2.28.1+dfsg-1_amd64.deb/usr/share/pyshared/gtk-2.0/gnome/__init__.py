# -*- Mode: Python; py-indent-offset: 4 -*-

# this can go when things are a little further along
# try:
#     import ltihooks
#     del ltihooks
# except ImportError:
#     pass

import gobject
del gobject

from _gnome import *
init = program_init

