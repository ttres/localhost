# -*- coding: utf8 -*-

glade_data = """<?xml version="1.0" encoding="UTF-8"?>
<interface>
  <requires lib="gtk+" version="2.16"/>
  <!-- interface-naming-policy project-wide -->
  <object class="GtkDialog" id="about_dialog">
    <property name="width_request">400</property>
    <property name="height_request">500</property>
    <property name="can_focus">False</property>
    <property name="border_width">5</property>
    <property name="title" translatable="yes">About</property>
    <property name="modal">True</property>
    <property name="type_hint">normal</property>
    <property name="skip_taskbar_hint">True</property>
    <property name="skip_pager_hint">True</property>
    <property name="transient_for">window</property>
    <signal name="delete-event" handler="on_about_close" swapped="no"/>
    <child internal-child="vbox">
      <object class="GtkVBox" id="dialog-vbox8">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="spacing">4</property>
        <child internal-child="action_area">
          <object class="GtkHButtonBox" id="dialog-action_area8">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="layout_style">end</property>
            <child>
              <placeholder/>
            </child>
            <child>
              <object class="GtkButton" id="button1">
                <property name="label">gtk-close</property>
                <property name="visible">True</property>
                <property name="can_focus">True</property>
                <property name="receives_default">True</property>
                <property name="use_action_appearance">False</property>
                <property name="use_stock">True</property>
                <signal name="clicked" handler="on_about_close" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="fill">False</property>
                <property name="position">1</property>
              </packing>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="pack_type">end</property>
            <property name="position">0</property>
          </packing>
        </child>
        <child>
          <object class="GtkLabel" id="label3">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label" translatable="yes">&lt;span weight="bold" size="x-large"&gt;Folding@home Client Control&lt;/span&gt;</property>
            <property name="use_markup">True</property>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">1</property>
          </packing>
        </child>
        <child>
          <object class="GtkLabel" id="about_version">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="use_markup">True</property>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">2</property>
          </packing>
        </child>
        <child>
          <object class="GtkImage" id="about_icon">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="stock">gtk-missing-image</property>
            <property name="icon-size">6</property>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">3</property>
          </packing>
        </child>
        <child>
          <object class="GtkLabel" id="wlabel33">
            <property name="width_request">1</property>
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="xalign">0</property>
            <property name="label" translatable="yes">This application allows you to monitor and control one or more Folding@home version 7 or newer console clients.</property>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">4</property>
          </packing>
        </child>
        <child>
          <object class="GtkLabel" id="label39">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label" translatable="yes">Copyright © 2010-2012 Stanford University</property>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">5</property>
          </packing>
        </child>
        <child>
          <object class="GtkLinkButton" id="linkbutton2">
            <property name="label" translatable="yes">http://folding.stanford.edu/</property>
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="receives_default">True</property>
            <property name="use_action_appearance">False</property>
            <property name="relief">none</property>
            <property name="uri">http://folding.stanford.edu/</property>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">6</property>
          </packing>
        </child>
        <child>
          <object class="GtkLabel" id="label81">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label" translatable="yes">For help see:</property>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">7</property>
          </packing>
        </child>
        <child>
          <object class="GtkLinkButton" id="linkbutton3">
            <property name="label" translatable="yes">http://foldingforum.org/</property>
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="receives_default">True</property>
            <property name="use_action_appearance">False</property>
            <property name="relief">none</property>
            <property name="uri">http://foldingforum.org/</property>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">8</property>
          </packing>
        </child>
        <child>
          <object class="GtkLinkButton" id="linkbutton4">
            <property name="label" translatable="yes">License: GPL v3.0</property>
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="receives_default">False</property>
            <property name="use_action_appearance">False</property>
            <property name="relief">none</property>
            <property name="uri">http://www.gnu.org/licenses/gpl-3.0-standalone.html</property>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">9</property>
          </packing>
        </child>
        <child>
          <object class="GtkFrame" id="frame4">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label_xalign">0</property>
            <child>
              <object class="GtkAlignment" id="alignment40">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <child>
                  <object class="GtkScrolledWindow" id="scrolledwindow17">
                    <property name="visible">True</property>
                    <property name="can_focus">True</property>
                    <property name="hscrollbar_policy">automatic</property>
                    <property name="vscrollbar_policy">automatic</property>
                    <child>
                      <object class="GtkViewport" id="viewport15">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="resize_mode">queue</property>
                        <property name="shadow_type">none</property>
                        <child>
                          <object class="GtkVBox" id="vbox30">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="spacing">8</property>
                            <child>
                              <object class="GtkLabel" id="label91">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label" translatable="yes">&lt;b&gt;Project Leader&lt;/b&gt;
Dr. Vijay Pande
Stanford University</property>
                                <property name="use_markup">True</property>
                                <property name="justify">center</property>
                              </object>
                              <packing>
                                <property name="expand">False</property>
                                <property name="fill">True</property>
                                <property name="position">0</property>
                              </packing>
                            </child>
                            <child>
                              <object class="GtkLabel" id="label93">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label" translatable="yes">&lt;b&gt;Developer&lt;/b&gt;
Joseph Coffland
Cauldron Development LLC</property>
                                <property name="use_markup">True</property>
                                <property name="justify">center</property>
                              </object>
                              <packing>
                                <property name="expand">False</property>
                                <property name="fill">True</property>
                                <property name="position">1</property>
                              </packing>
                            </child>
                            <child>
                              <object class="GtkLabel" id="label99">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label" translatable="yes">&lt;b&gt;Testers&lt;/b&gt;
Bruce Borden, bborden
Ivo Sarak, Ivoshiee
Thomas Fourcade, toTOW
Tim Braun, 7im
Carl Moudy, ChelseaOilman
Jean Hunter, susato
David Richard, RipD
Charles Richards, ChasR
Mark Turner, P5-133XL
Tim Thomas, hrsetrdr
Andy Van de Walle, Rum@NoV
Erwin Gies, SandStar
Anand Bhat, AnandBhat
Kevin Bernhagen, calxalot
Charles Oliver, 7up1n
Syed Mohammad Hussain Abdul Aziz, PantherX</property>
                                <property name="use_markup">True</property>
                                <property name="justify">center</property>
                              </object>
                              <packing>
                                <property name="expand">False</property>
                                <property name="fill">True</property>
                                <property name="position">2</property>
                              </packing>
                            </child>
                          </object>
                        </child>
                      </object>
                    </child>
                  </object>
                </child>
              </object>
            </child>
            <child type="label">
              <object class="GtkLabel" id="label89">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="label" translatable="yes">&lt;b&gt;Credits&lt;/b&gt;</property>
                <property name="use_markup">True</property>
              </object>
            </child>
          </object>
          <packing>
            <property name="expand">True</property>
            <property name="fill">True</property>
            <property name="position">10</property>
          </packing>
        </child>
      </object>
    </child>
    <action-widgets>
      <action-widget response="0">button1</action-widget>
    </action-widgets>
  </object>
  <object class="GtkAdjustment" id="checkpoint_adjustment">
    <property name="lower">3</property>
    <property name="upper">30</property>
    <property name="value">15</property>
    <property name="step_increment">3</property>
    <property name="page_increment">9</property>
  </object>
  <object class="GtkDialog" id="client_dialog">
    <property name="width_request">700</property>
    <property name="height_request">600</property>
    <property name="can_focus">False</property>
    <property name="border_width">5</property>
    <property name="title" translatable="yes">Configure</property>
    <property name="modal">True</property>
    <property name="destroy_with_parent">True</property>
    <property name="type_hint">normal</property>
    <property name="skip_taskbar_hint">True</property>
    <property name="skip_pager_hint">True</property>
    <property name="transient_for">window</property>
    <signal name="delete-event" handler="on_client_cancel" swapped="no"/>
    <child internal-child="vbox">
      <object class="GtkVBox" id="dialog-vbox3">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="spacing">2</property>
        <child internal-child="action_area">
          <object class="GtkHButtonBox" id="dialog-action_area3">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="layout_style">end</property>
            <child>
              <object class="GtkButton" id="client_ok_button">
                <property name="label">gtk-save</property>
                <property name="visible">True</property>
                <property name="can_focus">True</property>
                <property name="receives_default">True</property>
                <property name="use_action_appearance">False</property>
                <property name="use_stock">True</property>
                <signal name="clicked" handler="on_client_ok" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="fill">False</property>
                <property name="position">0</property>
              </packing>
            </child>
            <child>
              <object class="GtkButton" id="client_cancel_button">
                <property name="label">gtk-cancel</property>
                <property name="visible">True</property>
                <property name="can_focus">True</property>
                <property name="receives_default">True</property>
                <property name="use_action_appearance">False</property>
                <property name="use_stock">True</property>
                <signal name="clicked" handler="on_client_cancel" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="fill">False</property>
                <property name="position">1</property>
              </packing>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="pack_type">end</property>
            <property name="position">0</property>
          </packing>
        </child>
        <child>
          <object class="GtkFrame" id="frame6">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label_xalign">0</property>
            <child>
              <object class="GtkAlignment" id="alignment1">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="top_padding">4</property>
                <property name="bottom_padding">4</property>
                <property name="left_padding">4</property>
                <property name="right_padding">4</property>
                <child>
                  <object class="GtkVBox" id="vbox4">
                    <property name="visible">True</property>
                    <property name="can_focus">False</property>
                    <child>
                      <object class="GtkNotebook" id="client_config_notebook">
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <child>
                          <object class="GtkAlignment" id="connection_tab">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="top_padding">4</property>
                            <property name="bottom_padding">4</property>
                            <property name="left_padding">4</property>
                            <property name="right_padding">4</property>
                            <child>
                              <object class="GtkFrame" id="frame22">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <child>
                                  <object class="GtkScrolledWindow" id="scrolledwindow14">
                                    <property name="visible">True</property>
                                    <property name="can_focus">True</property>
                                    <property name="hscrollbar_policy">automatic</property>
                                    <property name="vscrollbar_policy">automatic</property>
                                    <child>
                                      <object class="GtkViewport" id="viewport13">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <property name="resize_mode">queue</property>
                                        <property name="shadow_type">none</property>
                                        <child>
                                          <object class="GtkAlignment" id="alignment29">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="left_padding">12</property>
                                            <child>
                                              <object class="GtkVBox" id="vbox19">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <child>
                                                  <object class="GtkLabel" id="wlabel6">
                                                    <property name="width_request">10</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="xalign">0</property>
                                                    <property name="yalign">0</property>
                                                    <property name="label" translatable="yes">Configure the GUI client's connection to an actual Folding@home client.  The client can either be local or on a remote machine.</property>
                                                    <property name="width_chars">100</property>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">0</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame23">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment30">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox20">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel7">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">Give the client a display name.  "local" client name cannot be changed.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkEntry" id="name_entry">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label41">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Name&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">1</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame24">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment31">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox21">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel8">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="label" translatable="yes">Specify the network address either as an IP of the form ###.###.###.### or a hostname.  "local" client address cannot be changed.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox22">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="label42">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="xpad">4</property>
                                                            <property name="label" translatable="yes">Hostname or IP:</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkEntry" id="address_entry">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="text" translatable="yes">localhost</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel9">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="label" translatable="yes">The port must match the configuration in the client.  The default port is 36330.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">2</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox23">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="label43">
                                                            <property name="width_request">80</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="xpad">4</property>
                                                            <property name="label" translatable="yes">Port:</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkSpinButton" id="port_entry">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            <property name="adjustment">port_adjustment</property>
                                                            <property name="numeric">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">3</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label44">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Address&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">2</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame25">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment45">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox22">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel10">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="label" translatable="yes">Specify a password for secure access to the client.  This keeps others from being able to control your client remotely, if it is not already protected by a firewall.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkEntry" id="password_entry">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="visibility">False</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="invisible_char_set">True</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label45">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Password&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">3</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="local_client_frame">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment48">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox31">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel11">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="label" translatable="yes">This is the configuration for the local client which can be manually started and stopped from here.  A new local client will not be started if one is already running on this address and port.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox31">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkButton" id="local_client_button">
                                                            <property name="label" translatable="yes">Start</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <signal name="clicked" handler="on_local_client_button" swapped="no"/>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label103">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="xpad">2</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label95">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Local Client&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">4</property>
                                                  </packing>
                                                </child>
                                              </object>
                                            </child>
                                          </object>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="label79">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;Client connection&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                            </child>
                          </object>
                        </child>
                        <child type="tab">
                          <object class="GtkLabel" id="connection_tab_label">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="label" translatable="yes">Connection</property>
                          </object>
                          <packing>
                            <property name="tab_fill">False</property>
                          </packing>
                        </child>
                        <child>
                          <object class="GtkAlignment" id="identity_tab">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="top_padding">4</property>
                            <property name="bottom_padding">4</property>
                            <property name="left_padding">4</property>
                            <property name="right_padding">4</property>
                            <child>
                              <object class="GtkFrame" id="frame7">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <child>
                                  <object class="GtkScrolledWindow" id="scrolledwindow7">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="hscrollbar_policy">automatic</property>
                                    <property name="vscrollbar_policy">automatic</property>
                                    <child>
                                      <object class="GtkViewport" id="viewport7">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <property name="resize_mode">queue</property>
                                        <property name="shadow_type">none</property>
                                        <child>
                                          <object class="GtkAlignment" id="alignment8">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="left_padding">12</property>
                                            <child>
                                              <object class="GtkVBox" id="vbox8">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="spacing">4</property>
                                                <child>
                                                  <object class="GtkFrame" id="frame8">
                                                    <property name="width_request">580</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment9">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <property name="right_padding">4</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox5">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel12">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">The name, or alias, you enter here will be displayed in the statistics page on our web site.  If you choose not to enter a name, your computer's time will be donated anonymously.  These settings may be changed at any time.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox6">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkEntry" id="user_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="text" translatable="yes">anonymous</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label26">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Name&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="padding">2</property>
                                                    <property name="position">0</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame9">
                                                    <property name="width_request">580</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment10">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <property name="right_padding">4</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox6">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel13">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">You may also join a team.  If you want your work to count for a team, enter the team number here.  See the Folding@home Web site to find out how to start a team.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox5">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkSpinButton" id="team_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            <property name="adjustment">team_adjustment</property>
                                                            <property name="numeric">True</property>
                                                            <property name="update_policy">if-valid</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="padding">4</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label19">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Team number&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="padding">2</property>
                                                    <property name="position">1</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame10">
                                                    <property name="width_request">580</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment11">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <property name="right_padding">4</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox7">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox11">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLinkButton" id="linkbutton1">
                                                            <property name="label" translatable="yes">Click here to open the Folding@home passkey request Web page</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="relief">none</property>
                                                            <property name="uri">http://fah-web.stanford.edu/cgi-bin/getpasskey.py</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label5">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel14">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">For added security, you can request a passkey and enter it here.  This helps to prevent others from pretending to be you.  You are responsible for keeping your passkey a secret.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox7">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkTable" id="table7">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="n_rows">3</property>
                                                            <property name="n_columns">2</property>
                                                            <property name="column_spacing">4</property>
                                                            <child>
                                                            <object class="GtkEntry" id="passkey_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="visibility">False</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkEntry" id="passkey_reenter">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="visibility">False</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label69">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Passkey&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label70">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Reenter&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label71">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Valid&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">2</property>
                                                            <property name="bottom_attach">3</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox34">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="spacing">4</property>
                                                            <child>
                                                            <object class="GtkImage" id="passkey_valid_image">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="stock">gtk-dialog-error</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="passkey_valid_text">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">2</property>
                                                            <property name="bottom_attach">3</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="padding">4</property>
                                                            <property name="position">2</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label24">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Passkey&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="padding">2</property>
                                                    <property name="position">2</property>
                                                  </packing>
                                                </child>
                                              </object>
                                            </child>
                                          </object>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="label17">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;How would you like to be credited?&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                            </child>
                          </object>
                          <packing>
                            <property name="position">1</property>
                          </packing>
                        </child>
                        <child type="tab">
                          <object class="GtkLabel" id="identity_tab_label">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="label" translatable="yes">Identity</property>
                          </object>
                          <packing>
                            <property name="position">1</property>
                            <property name="tab_fill">False</property>
                          </packing>
                        </child>
                        <child>
                          <object class="GtkAlignment" id="advanced_slots_tab">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="top_padding">4</property>
                            <property name="bottom_padding">4</property>
                            <property name="left_padding">4</property>
                            <property name="right_padding">4</property>
                            <child>
                              <object class="GtkFrame" id="frame11">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <child>
                                  <object class="GtkScrolledWindow" id="scrolledwindow5">
                                    <property name="visible">True</property>
                                    <property name="can_focus">True</property>
                                    <property name="hscrollbar_policy">automatic</property>
                                    <property name="vscrollbar_policy">automatic</property>
                                    <child>
                                      <object class="GtkViewport" id="viewport5">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <property name="resize_mode">queue</property>
                                        <property name="shadow_type">none</property>
                                        <child>
                                          <object class="GtkAlignment" id="alignment14">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="left_padding">12</property>
                                            <child>
                                              <object class="GtkVBox" id="vbox9">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <child>
                                                  <object class="GtkLabel" id="wlabel15">
                                                    <property name="width_request">1</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="xalign">0</property>
                                                    <property name="yalign">0</property>
                                                    <property name="label" translatable="yes">If you do not define any folding slots the client will try to choose a good configuration for you automatically.  So you can safely ignore this section.

Folding slots can be one of three types, Uniprocessor, SMP or GPU.  Representing the different types of Folding@home cores.  Expert users can configure many details of each slot but that is usually not necessary.</property>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">0</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame13">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment19">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox12">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkScrolledWindow" id="scrolledwindow12">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="hscrollbar_policy">automatic</property>
                                                            <property name="vscrollbar_policy">automatic</property>
                                                            <child>
                                                            <object class="GtkViewport" id="viewport11">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="resize_mode">queue</property>
                                                            <child>
                                                            <object class="GtkTreeView" id="slot_tree_view">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="model">slot_list</property>
                                                            <property name="headers_clickable">False</property>
                                                            <property name="rules_hint">True</property>
                                                            <property name="search_column">0</property>
                                                            <signal name="row-activated" handler="on_slot_tree_view_row_activated" swapped="no"/>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="treeviewcolumn2">
                                                            <property name="title">ID</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="cellrenderertext22"/>
                                                            <attributes>
                                                            <attribute name="text">0</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="treeviewcolumn3">
                                                            <property name="title">Type</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="cellrenderertext23"/>
                                                            <attributes>
                                                            <attribute name="text">1</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox8">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="label28">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox9">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkButton" id="slot_add_button">
                                                            <property name="label">gtk-add</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="use_stock">True</property>
                                                            <signal name="clicked" handler="on_slot_add_button_clicked" swapped="no"/>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkButton" id="slot_remove_button">
                                                            <property name="label">gtk-remove</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="use_stock">True</property>
                                                            <signal name="clicked" handler="on_slot_remove_button_clicked" swapped="no"/>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkButton" id="slot_edit_button">
                                                            <property name="label">gtk-edit</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="use_stock">True</property>
                                                            <signal name="clicked" handler="on_slot_edit_button_clicked" swapped="no"/>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">2</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label29">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Folding slots&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">True</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">1</property>
                                                  </packing>
                                                </child>
                                              </object>
                                            </child>
                                          </object>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="label20">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;Configure client folding slots&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                            </child>
                          </object>
                          <packing>
                            <property name="position">2</property>
                          </packing>
                        </child>
                        <child type="tab">
                          <object class="GtkLabel" id="slot_tab_label">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="label" translatable="yes">Slots</property>
                          </object>
                          <packing>
                            <property name="position">2</property>
                            <property name="tab_fill">False</property>
                          </packing>
                        </child>
                        <child>
                          <object class="GtkAlignment" id="advanced_remote_tab">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="top_padding">4</property>
                            <property name="bottom_padding">4</property>
                            <property name="left_padding">4</property>
                            <property name="right_padding">4</property>
                            <child>
                              <object class="GtkFrame" id="frame36">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <child>
                                  <object class="GtkScrolledWindow" id="scrolledwindow11">
                                    <property name="visible">True</property>
                                    <property name="can_focus">True</property>
                                    <property name="hscrollbar_policy">automatic</property>
                                    <property name="vscrollbar_policy">automatic</property>
                                    <child>
                                      <object class="GtkViewport" id="viewport1">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <property name="resize_mode">queue</property>
                                        <property name="shadow_type">none</property>
                                        <child>
                                          <object class="GtkAlignment" id="alignment15">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="left_padding">12</property>
                                            <child>
                                              <object class="GtkVBox" id="vbox33">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="spacing">2</property>
                                                <child>
                                                  <object class="GtkLabel" id="wlabel16">
                                                    <property name="width_request">1</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="xalign">0</property>
                                                    <property name="yalign">0</property>
                                                    <property name="label" translatable="yes">The options in this section can be used to configure remote access to Folding@home clients.  This is mainly only useful to expert users running multiple clients which they would like to monitor and control from another computer.  These options may be safely ignored as the defaults are safe and will not allow any remote access.

In addition to the settings here, you may also have to open access to the configured port in your firewall configuration for the machine or machines which will be allowed to remotely access this client.

Warning, the password set here is transmitted in clear text and is not meant to be a complete security solution.  If you intend to enable access to your Folding@home clients over the Internet then you should use additional security such as secure VPN, SSH tunneling or at a minimum IP based access restriction.

Warning, changes you make here may render your client inaccessible even from the local machine.  If this happens you will have to manually add your IP to 'command-allow' option in the client's 'config.xml' file and restart it.</property>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">0</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame37">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment16">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox34">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="spacing">8</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel17">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">If you set a password here clients will be required to enter this password to gain access to the console client.  Otherwise, only clients which are listed in the Passwordless IP Addresses section will be allowed to access this client.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTable" id="table6">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="n_rows">3</property>
                                                            <property name="n_columns">2</property>
                                                            <property name="column_spacing">4</property>
                                                            <child>
                                                            <object class="GtkEntry" id="password_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="visibility">False</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkEntry" id="password_reenter">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="visibility">False</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label60">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Password&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label61">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Reenter&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label68">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Valid&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">2</property>
                                                            <property name="bottom_attach">3</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox33">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="spacing">4</property>
                                                            <child>
                                                            <object class="GtkImage" id="password_valid_image">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="stock">gtk-dialog-error</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="password_valid_text">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">2</property>
                                                            <property name="bottom_attach">3</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label62">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Password&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">1</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame39">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment41">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox37">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="spacing">8</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel18">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">The network port used to access this client.  This must match the port in the configuration used to access this client.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox32">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkSpinButton" id="command_port_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            <property name="adjustment">command_port_adjustment</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label67">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label63">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Port&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">2</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame38">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment17">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox35">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="spacing">8</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel19">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">These fields restrict remote access to the client by allowing and denying IP address ranges.  The client first checks if the IP address matches one of the allowed IP ranges if true access is allowed.  Otherwise, if the IP address is in one  of the deny ranges access is denied.  If the IP address is in neither list access is allowed.

The fields below should contain space separated lists of IP addresses or IP address address ranges which may be specified in one of the two following formats:

  xxx.xxx.xxx.xxx-xxx.xxx.xxx.xxx
or
  xxx.xxx.xxx.xxx/bits

There can be no spaces between the - or / in the above formats.  The first format simply allows all IP addresses counting from the first to the second inclusive.  The second format is shorter and is commonly used in networking software.  The bits field in this format specifies how many bits are signifigant in the range starting from the left.  An IP address has a total of 32 bits.  So the following ranges are equivalent.

  192.168.0.0-192.168.0.255
or
  192.168.0.0/24

The following range specification matches all IP address:

  0.0.0.0/0</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTable" id="table8">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="n_rows">2</property>
                                                            <property name="n_columns">2</property>
                                                            <property name="column_spacing">4</property>
                                                            <child>
                                                            <object class="GtkEntry" id="command_allow_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkEntry" id="command_deny_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label72">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Allow&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label73">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Deny&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label64">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;IP Address Restriction&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">3</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame40">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment42">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox36">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="spacing">8</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel20">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">These fields accept the same format as above however, the IP address filter created by these fields will allowed to access the client with out a password.

Great care should be taken when modifying these fields.  Normally, only the local IP address 127.0.0.1 should be allowed unless your network is protected by other means and you would like more convenient access to this client.

Addresses listed here also need to be listed above to allow access.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTable" id="table9">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="n_rows">2</property>
                                                            <property name="n_columns">2</property>
                                                            <property name="column_spacing">4</property>
                                                            <child>
                                                            <object class="GtkEntry" id="command_allow_no_pass_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkEntry" id="command_deny_no_pass_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label74">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Allow&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label75">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Deny&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label65">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Passwordless IP Address Restriction&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">4</property>
                                                  </packing>
                                                </child>
                                              </object>
                                            </child>
                                          </object>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="label15">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;Console client remote access&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                            </child>
                          </object>
                          <packing>
                            <property name="position">3</property>
                          </packing>
                        </child>
                        <child type="tab">
                          <object class="GtkLabel" id="remote_tab_label">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="label" translatable="yes">Remote Access</property>
                          </object>
                          <packing>
                            <property name="position">3</property>
                            <property name="tab_fill">False</property>
                          </packing>
                        </child>
                        <child>
                          <object class="GtkAlignment" id="proxy_tab">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="top_padding">4</property>
                            <property name="bottom_padding">4</property>
                            <property name="left_padding">4</property>
                            <property name="right_padding">4</property>
                            <child>
                              <object class="GtkFrame" id="frame35">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <child>
                                  <object class="GtkScrolledWindow" id="scrolledwindow15">
                                    <property name="visible">True</property>
                                    <property name="can_focus">True</property>
                                    <property name="hscrollbar_policy">automatic</property>
                                    <property name="vscrollbar_policy">automatic</property>
                                    <child>
                                      <object class="GtkViewport" id="viewport14">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <property name="resize_mode">queue</property>
                                        <property name="shadow_type">none</property>
                                        <child>
                                          <object class="GtkAlignment" id="alignment49">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="left_padding">12</property>
                                            <child>
                                              <object class="GtkScrolledWindow" id="scrolledwindow20">
                                                <property name="visible">True</property>
                                                <property name="can_focus">True</property>
                                                <property name="hscrollbar_policy">automatic</property>
                                                <property name="vscrollbar_policy">automatic</property>
                                                <child>
                                                  <object class="GtkViewport" id="viewport17">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <child>
                                                      <object class="GtkVBox" id="vbox32">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="spacing">4</property>
                                                        <child>
                                                          <object class="GtkCheckButton" id="proxy_enable_option">
                                                            <property name="label" translatable="yes">Enable proxy configuration</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">False</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="yalign">0.4699999988079071</property>
                                                            <property name="draw_indicator">True</property>
                                                            <signal name="toggled" handler="on_proxy_enable_toggled" swapped="no"/>
                                                          </object>
                                                          <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                          </packing>
                                                        </child>
                                                        <child>
                                                          <object class="GtkFrame" id="proxy_frame">
                                                            <property name="width_request">580</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="label_xalign">0</property>
                                                            <child>
                                                            <object class="GtkAlignment" id="alignment50">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="left_padding">12</property>
                                                            <property name="right_padding">4</property>
                                                            <child>
                                                            <object class="GtkVBox" id="vbox38">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel21">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">The hostname or IP address and port of the HTTP proxy.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox35">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox37">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="label117">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="xpad">5</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Hostname or IP&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkEntry" id="proxy_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">•</property>
                                                            <property name="invisible_char_set">True</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label118">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="xpad">5</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Port&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">2</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkSpinButton" id="proxy_port_entry">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">•</property>
                                                            <property name="invisible_char_set">True</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            <property name="adjustment">proxy_port_adjustment</property>
                                                            <property name="numeric">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">3</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            <child type="label">
                                                            <object class="GtkLabel" id="label115">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Proxy&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            </child>
                                                          </object>
                                                          <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="padding">2</property>
                                                            <property name="position">1</property>
                                                          </packing>
                                                        </child>
                                                        <child>
                                                          <object class="GtkFrame" id="proxy_auth_frame">
                                                            <property name="width_request">580</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="label_xalign">0</property>
                                                            <child>
                                                            <object class="GtkAlignment" id="alignment51">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="left_padding">12</property>
                                                            <property name="right_padding">4</property>
                                                            <child>
                                                            <object class="GtkVBox" id="vbox39">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel22">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">The proxy user name and password if necessary.  The Folding@home client currently only supports basic and digest authentication.  Specifically NTLM, SOCKS and SSL/TLS proxies are not supported.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox36">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkTable" id="table13">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="n_rows">4</property>
                                                            <property name="n_columns">2</property>
                                                            <property name="column_spacing">4</property>
                                                            <child>
                                                            <object class="GtkEntry" id="proxy_pass_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="visibility">False</property>
                                                            <property name="invisible_char">•</property>
                                                            <property name="invisible_char_set">True</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkEntry" id="proxy_pass_reenter">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="visibility">False</property>
                                                            <property name="invisible_char">•</property>
                                                            <property name="invisible_char_set">True</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">2</property>
                                                            <property name="bottom_attach">3</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label123">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Password&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label124">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Reenter&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">2</property>
                                                            <property name="bottom_attach">3</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label125">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Valid&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">3</property>
                                                            <property name="bottom_attach">4</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox40">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="spacing">4</property>
                                                            <child>
                                                            <object class="GtkImage" id="proxy_pass_valid_image">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="stock">gtk-dialog-error</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="proxy_pass_valid_text">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">3</property>
                                                            <property name="bottom_attach">4</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label126">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Name&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkEntry" id="proxy_user_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">•</property>
                                                            <property name="invisible_char_set">True</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="padding">4</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            <child type="label">
                                                            <object class="GtkLabel" id="label116">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Proxy Authentication&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            </child>
                                                          </object>
                                                          <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="padding">2</property>
                                                            <property name="position">2</property>
                                                          </packing>
                                                        </child>
                                                      </object>
                                                    </child>
                                                  </object>
                                                </child>
                                              </object>
                                            </child>
                                          </object>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="label122">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;Configure Proxy Options&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                            </child>
                          </object>
                          <packing>
                            <property name="position">4</property>
                          </packing>
                        </child>
                        <child type="tab">
                          <object class="GtkLabel" id="label113">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="label" translatable="yes">Proxy</property>
                          </object>
                          <packing>
                            <property name="position">6</property>
                            <property name="tab_fill">False</property>
                          </packing>
                        </child>
                        <child>
                          <object class="GtkAlignment" id="advanced_tab">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="top_padding">4</property>
                            <property name="bottom_padding">4</property>
                            <property name="left_padding">4</property>
                            <property name="right_padding">4</property>
                            <child>
                              <object class="GtkFrame" id="frame12">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <child>
                                  <object class="GtkAlignment" id="alignment18">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="left_padding">12</property>
                                    <child>
                                      <object class="GtkScrolledWindow" id="scrolledwindow6">
                                        <property name="visible">True</property>
                                        <property name="can_focus">True</property>
                                        <property name="hscrollbar_policy">automatic</property>
                                        <property name="vscrollbar_policy">automatic</property>
                                        <child>
                                          <object class="GtkViewport" id="viewport6">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="resize_mode">queue</property>
                                            <property name="shadow_type">none</property>
                                            <child>
                                              <object class="GtkVBox" id="vbox10">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="spacing">4</property>
                                                <child>
                                                  <object class="GtkFrame" id="frame14">
                                                    <property name="width_request">580</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment20">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <property name="right_padding">4</property>
                                                        <child>
                                                          <object class="GtkTable" id="table3">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="n_rows">2</property>
                                                            <property name="n_columns">2</property>
                                                            <child>
                                                            <object class="GtkRadioButton" id="core_priority_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">False</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="active">True</property>
                                                            <property name="draw_indicator">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkRadioButton" id="core_priority_low">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">False</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="draw_indicator">True</property>
                                                            <property name="group">core_priority_option</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel23">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">Lowest possible (recommended)</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel24">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">Slightly higher.  Use this if other distributed computing applications are stopping Folding@home from running.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label23">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;FahCore Priority&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="padding">2</property>
                                                    <property name="position">0</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame15">
                                                    <property name="width_request">580</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment21">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <property name="right_padding">4</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox15">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkHScale" id="cpu_usage_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="adjustment">cpu_usage_adjustment</property>
                                                            <property name="digits">0</property>
                                                            <property name="value_pos">left</property>
                                                            <signal name="format-value" handler="on_cpu_usage_scale_format_value" swapped="no"/>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel25">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">Instruct Folding@home cores to only use this percentage of the available CPU.  (100% is recommended)</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label31">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Percent CPU usage&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="padding">2</property>
                                                    <property name="position">1</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame44">
                                                    <property name="width_request">580</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment54">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <property name="right_padding">4</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox41">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkHScale" id="gpu_usage_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="adjustment">gpu_usage_adjustment</property>
                                                            <property name="round_digits">0</property>
                                                            <property name="digits">0</property>
                                                            <property name="value_pos">left</property>
                                                            <signal name="format-value" handler="on_cpu_usage_scale_format_value" swapped="no"/>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel26">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">Instruct Folding@home GPU cores to use at most this percentage of the GPU's available processing power.  (80% is recommended)</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label128">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Percent GPU usage&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="padding">2</property>
                                                    <property name="position">2</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame17">
                                                    <property name="width_request">580</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment23">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <property name="right_padding">4</property>
                                                        <child>
                                                          <object class="GtkVBox" id="vbox14">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkHScale" id="checkpoint_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="adjustment">checkpoint_adjustment</property>
                                                            <property name="digits">0</property>
                                                            <property name="value_pos">left</property>
                                                            <signal name="format-value" handler="on_checkpoint_scale_format_value" swapped="no"/>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel27">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">Some cores maintain a maximum checkpoint internal.  A checkpoint saves the core's work so it can restart from the same point later in case the program ends unexpectedly.  This slider lets you control how often these checkpoints occur.  More frequent checkpointing reduces the amount of work that could be lost but decreases performance.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label33">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Checkpointing frequency&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="padding">2</property>
                                                    <property name="position">3</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame16">
                                                    <property name="width_request">580</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment22">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <property name="right_padding">4</property>
                                                        <child>
                                                          <object class="GtkTable" id="table15">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="n_rows">2</property>
                                                            <property name="n_columns">2</property>
                                                            <child>
                                                            <object class="GtkCheckButton" id="no_assembly_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">False</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="draw_indicator">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="x_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkCheckButton" id="cpu_affinity_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">False</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="draw_indicator">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel28">
                                                            <property name="width_request">100</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">Disable highly optimized assembly code.  Useful if core fails to run because of unsupported instructions.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel29">
                                                            <property name="width_request">100</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">Try to lock cores to a specific CPU.  Also known as CPU affinity locking.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label32">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Optimizations&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="padding">2</property>
                                                    <property name="position">4</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame18">
                                                    <property name="width_request">580</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment24">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <property name="right_padding">4</property>
                                                        <child>
                                                          <object class="GtkHBox" id="hbox17">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkCheckButton" id="pause_on_battery_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">False</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="draw_indicator">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel30">
                                                            <property name="width_request">100</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="yalign">0</property>
                                                            <property name="label" translatable="yes">Pause work while on battery power.  This is useful for laptops.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label34">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Power&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="padding">2</property>
                                                    <property name="position">5</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="frame19">
                                                    <property name="width_request">580</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment25">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="left_padding">12</property>
                                                        <property name="right_padding">4</property>
                                                        <child>
                                                          <object class="GtkHBox" id="hbox18">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkSpinButton" id="verbosity_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            <property name="adjustment">verbosity_adjustment</property>
                                                            <property name="numeric">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="wlabel31">
                                                            <property name="width_request">100</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="label" translatable="yes">Set log verbosity level.  Level 0 turns off all but errors and warnings.  Levels 1 to 5 add increasingly more detail to the log.  Level 3 is recommended.</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label35">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Verbosity&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="padding">2</property>
                                                    <property name="position">6</property>
                                                  </packing>
                                                </child>
                                              </object>
                                            </child>
                                          </object>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="label22">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;Client configuration items for advanced users&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                            </child>
                          </object>
                          <packing>
                            <property name="position">5</property>
                          </packing>
                        </child>
                        <child type="tab">
                          <object class="GtkLabel" id="advanced_tab_label">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="label" translatable="yes">Advanced</property>
                          </object>
                          <packing>
                            <property name="position">5</property>
                            <property name="tab_fill">False</property>
                          </packing>
                        </child>
                        <child>
                          <object class="GtkAlignment" id="expert_tab">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="top_padding">4</property>
                            <property name="bottom_padding">4</property>
                            <property name="left_padding">4</property>
                            <property name="right_padding">4</property>
                            <child>
                              <object class="GtkFrame" id="frame20">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <child>
                                  <object class="GtkScrolledWindow" id="scrolledwindow2">
                                    <property name="visible">True</property>
                                    <property name="can_focus">True</property>
                                    <property name="hscrollbar_policy">automatic</property>
                                    <property name="vscrollbar_policy">automatic</property>
                                    <child>
                                      <object class="GtkViewport" id="viewport3">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <property name="resize_mode">queue</property>
                                        <property name="shadow_type">none</property>
                                        <child>
                                          <object class="GtkAlignment" id="alignment26">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="left_padding">12</property>
                                            <child>
                                              <object class="GtkVBox" id="vbox11">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <child>
                                                  <object class="GtkLabel" id="wlabel32">
                                                    <property name="width_request">100</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="xalign">0</property>
                                                    <property name="yalign">0</property>
                                                    <property name="label" translatable="yes">Changing configuration options in this section may break your client, cost you points, or damage your or your team's standing with the Folding@home project.  Only make changes here if you know what you are doing or have been so instructed by a member of the Folding@home team.

Some of these options may require manually restarting the client to take effect.</property>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">0</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkHBox" id="hbox3">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <child>
                                                      <object class="GtkFrame" id="frame41">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label_xalign">0</property>
                                                        <child>
                                                          <object class="GtkAlignment" id="alignment43">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkVBox" id="vbox13">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkScrolledWindow" id="scrolledwindow8">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="hscrollbar_policy">automatic</property>
                                                            <property name="vscrollbar_policy">automatic</property>
                                                            <child>
                                                            <object class="GtkViewport" id="viewport8">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="resize_mode">queue</property>
                                                            <child>
                                                            <object class="GtkTreeView" id="option_tree_view">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="model">option_list</property>
                                                            <property name="headers_clickable">False</property>
                                                            <property name="rules_hint">True</property>
                                                            <property name="search_column">0</property>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="treeviewcolumn4">
                                                            <property name="title">Name</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="option_name_cell">
                                                            <property name="editable">True</property>
                                                            </object>
                                                            <attributes>
                                                            <attribute name="text">0</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="treeviewcolumn5">
                                                            <property name="title">Value</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="option_value_cell">
                                                            <property name="editable">True</property>
                                                            </object>
                                                            <attributes>
                                                            <attribute name="text">1</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox4">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="label25">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox21">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkButton" id="client_options_add_button">
                                                            <property name="label">gtk-add</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="use_stock">True</property>
                                                            <signal name="clicked" handler="on_client_options_add_button_clicked" swapped="no"/>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkButton" id="client_options_remove_button">
                                                            <property name="label">gtk-remove</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="use_stock">True</property>
                                                            <signal name="clicked" handler="on_client_options_remove_button_clicked" swapped="no"/>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            </child>
                                                          </object>
                                                        </child>
                                                        <child type="label">
                                                          <object class="GtkLabel" id="label27">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Extra client options&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                          </object>
                                                        </child>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">True</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">0</property>
                                                      </packing>
                                                    </child>
                                                    <child>
                                                      <object class="GtkFrame" id="frame42">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label_xalign">0</property>
                                                        <child>
                                                          <object class="GtkAlignment" id="alignment44">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkVBox" id="vbox17">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkScrolledWindow" id="scrolledwindow13">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="hscrollbar_policy">automatic</property>
                                                            <property name="vscrollbar_policy">automatic</property>
                                                            <child>
                                                            <object class="GtkViewport" id="viewport12">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="resize_mode">queue</property>
                                                            <child>
                                                            <object class="GtkTreeView" id="core_option_tree_view">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="model">core_option_list</property>
                                                            <property name="headers_clickable">False</property>
                                                            <property name="rules_hint">True</property>
                                                            <property name="search_column">0</property>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="treeviewcolumn6">
                                                            <property name="title">Option</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="core_option_cell">
                                                            <property name="editable">True</property>
                                                            <signal name="edited" handler="on_core_option_cell_edited" swapped="no"/>
                                                            </object>
                                                            <attributes>
                                                            <attribute name="text">0</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox19">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkLabel" id="label36">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkHBox" id="hbox20">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkButton" id="core_options_add_button">
                                                            <property name="label">gtk-add</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="use_stock">True</property>
                                                            <signal name="clicked" handler="on_core_options_add_button_clicked" swapped="no"/>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkButton" id="core_options_remove_button">
                                                            <property name="label">gtk-remove</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="use_stock">True</property>
                                                            <signal name="clicked" handler="on_core_options_remove_button_clicked" swapped="no"/>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            </child>
                                                          </object>
                                                        </child>
                                                        <child type="label">
                                                          <object class="GtkLabel" id="label37">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Extra core options&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                          </object>
                                                        </child>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">True</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">1</property>
                                                      </packing>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">True</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">1</property>
                                                  </packing>
                                                </child>
                                              </object>
                                            </child>
                                          </object>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="label80">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;Client configuration options for experts only&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                            </child>
                          </object>
                          <packing>
                            <property name="position">6</property>
                          </packing>
                        </child>
                        <child type="tab">
                          <object class="GtkLabel" id="expert_tab_label">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="label" translatable="yes">Expert</property>
                          </object>
                          <packing>
                            <property name="position">6</property>
                            <property name="tab_fill">False</property>
                          </packing>
                        </child>
                      </object>
                      <packing>
                        <property name="expand">True</property>
                        <property name="fill">True</property>
                        <property name="position">2</property>
                      </packing>
                    </child>
                  </object>
                </child>
              </object>
            </child>
            <child type="label">
              <object class="GtkLabel" id="client_config_label">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="label" translatable="yes">&lt;b&gt;Client: inactive&lt;/b&gt;</property>
                <property name="use_markup">True</property>
              </object>
            </child>
          </object>
          <packing>
            <property name="expand">True</property>
            <property name="fill">True</property>
            <property name="position">1</property>
          </packing>
        </child>
      </object>
    </child>
    <action-widgets>
      <action-widget response="0">client_ok_button</action-widget>
      <action-widget response="0">client_cancel_button</action-widget>
    </action-widgets>
  </object>
  <object class="GtkListStore" id="client_list">
    <columns>
      <!-- column-name name -->
      <column type="gchararray"/>
      <!-- column-name status -->
      <column type="gchararray"/>
      <!-- column-name status_color -->
      <column type="gchararray"/>
      <!-- column-name address -->
      <column type="gchararray"/>
    </columns>
  </object>
  <object class="GtkAdjustment" id="command_port_adjustment">
    <property name="upper">65535</property>
    <property name="value">36330</property>
    <property name="step_increment">1</property>
    <property name="page_increment">100</property>
  </object>
  <object class="GtkListStore" id="core_option_list">
    <columns>
      <!-- column-name option -->
      <column type="gchararray"/>
    </columns>
  </object>
  <object class="GtkDialog" id="core_options_dialog">
    <property name="can_focus">False</property>
    <property name="border_width">5</property>
    <property name="title" translatable="yes">Edit Core Option</property>
    <property name="modal">True</property>
    <property name="window_position">center-on-parent</property>
    <property name="type_hint">normal</property>
    <property name="skip_taskbar_hint">True</property>
    <property name="skip_pager_hint">True</property>
    <property name="transient_for">window</property>
    <signal name="delete-event" handler="on_core_options_cancel" swapped="no"/>
    <child internal-child="vbox">
      <object class="GtkVBox" id="dialog-vbox7">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="spacing">2</property>
        <child internal-child="action_area">
          <object class="GtkHButtonBox" id="dialog-action_area7">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="layout_style">end</property>
            <child>
              <object class="GtkButton" id="core_options_ok_button">
                <property name="label">gtk-ok</property>
                <property name="visible">True</property>
                <property name="can_focus">True</property>
                <property name="receives_default">True</property>
                <property name="use_action_appearance">False</property>
                <property name="use_stock">True</property>
                <signal name="clicked" handler="on_core_options_ok" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="fill">False</property>
                <property name="position">0</property>
              </packing>
            </child>
            <child>
              <object class="GtkButton" id="core_options_cancel_button">
                <property name="label">gtk-cancel</property>
                <property name="visible">True</property>
                <property name="can_focus">True</property>
                <property name="receives_default">True</property>
                <property name="use_action_appearance">False</property>
                <property name="use_stock">True</property>
                <signal name="clicked" handler="on_core_options_cancel" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="fill">False</property>
                <property name="position">1</property>
              </packing>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="pack_type">end</property>
            <property name="position">0</property>
          </packing>
        </child>
        <child>
          <object class="GtkFrame" id="frame34">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label_xalign">0</property>
            <child>
              <object class="GtkAlignment" id="alignment2">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="left_padding">12</property>
                <child>
                  <object class="GtkEntry" id="core_option_entry">
                    <property name="visible">True</property>
                    <property name="can_focus">True</property>
                    <property name="invisible_char">●</property>
                    <property name="primary_icon_activatable">False</property>
                    <property name="secondary_icon_activatable">False</property>
                    <property name="primary_icon_sensitive">True</property>
                    <property name="secondary_icon_sensitive">True</property>
                  </object>
                </child>
              </object>
            </child>
            <child type="label">
              <object class="GtkLabel" id="label30">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="label" translatable="yes">&lt;b&gt;Edit core option&lt;/b&gt;</property>
                <property name="use_markup">True</property>
              </object>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">1</property>
          </packing>
        </child>
      </object>
    </child>
    <action-widgets>
      <action-widget response="0">core_options_ok_button</action-widget>
      <action-widget response="0">core_options_cancel_button</action-widget>
    </action-widgets>
  </object>
  <object class="GtkAdjustment" id="cpu_usage_adjustment">
    <property name="upper">100</property>
    <property name="value">100</property>
    <property name="step_increment">1</property>
    <property name="page_increment">10</property>
  </object>
  <object class="GtkAdjustment" id="cpus_adjustment">
    <property name="lower">-1</property>
    <property name="upper">1000000</property>
    <property name="value">-1</property>
    <property name="step_increment">1</property>
    <property name="page_increment">1</property>
  </object>
  <object class="GtkAdjustment" id="cuda_index_adjustment">
    <property name="lower">-1</property>
    <property name="upper">1000000</property>
    <property name="value">-1</property>
    <property name="step_increment">1</property>
    <property name="page_increment">1</property>
  </object>
  <object class="GtkListStore" id="donor_stats_links_list">
    <columns>
      <!-- column-name name -->
      <column type="gchararray"/>
      <!-- column-name url -->
      <column type="gchararray"/>
    </columns>
  </object>
  <object class="GtkAdjustment" id="gpu_index_adjustment">
    <property name="lower">-1</property>
    <property name="upper">1000000</property>
    <property name="value">-1</property>
    <property name="step_increment">1</property>
    <property name="page_increment">1</property>
  </object>
  <object class="GtkAdjustment" id="gpu_usage_adjustment">
    <property name="upper">100</property>
    <property name="step_increment">1</property>
    <property name="page_increment">10</property>
  </object>
  <object class="GtkImage" id="image1">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-media-next</property>
  </object>
  <object class="GtkImage" id="image10">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-missing-image</property>
  </object>
  <object class="GtkImage" id="image11">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-media-play</property>
  </object>
  <object class="GtkImage" id="image12">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-media-pause</property>
  </object>
  <object class="GtkImage" id="image13">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-media-next</property>
  </object>
  <object class="GtkImage" id="image14">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-missing-image</property>
  </object>
  <object class="GtkImage" id="image15">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-missing-image</property>
  </object>
  <object class="GtkImage" id="image16">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-refresh</property>
  </object>
  <object class="GtkImage" id="image17">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-refresh</property>
  </object>
  <object class="GtkImage" id="image18">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-refresh</property>
  </object>
  <object class="GtkImage" id="image19">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-refresh</property>
  </object>
  <object class="GtkImage" id="image2">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-media-play</property>
  </object>
  <object class="GtkImage" id="image20">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-refresh</property>
  </object>
  <object class="GtkImage" id="image21">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-refresh</property>
  </object>
  <object class="GtkImage" id="image3">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-media-play</property>
  </object>
  <object class="GtkImage" id="image4">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-media-next</property>
  </object>
  <object class="GtkImage" id="image5">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-goto-top</property>
  </object>
  <object class="GtkImage" id="image6">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-media-pause</property>
  </object>
  <object class="GtkImage" id="image7">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-missing-image</property>
  </object>
  <object class="GtkImage" id="image8">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-missing-image</property>
  </object>
  <object class="GtkImage" id="image9">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <property name="stock">gtk-refresh</property>
  </object>
  <object class="GtkTextBuffer" id="info_buffer"/>
  <object class="GtkTextBuffer" id="log_buffer"/>
  <object class="GtkListStore" id="log_severity_list">
    <columns>
      <!-- column-name severity -->
      <column type="gchararray"/>
    </columns>
    <data>
      <row>
        <col id="0" translatable="yes">Any</col>
      </row>
      <row>
        <col id="0" translatable="yes">Warning</col>
      </row>
      <row>
        <col id="0" translatable="yes">Error</col>
      </row>
    </data>
  </object>
  <object class="GtkListStore" id="mode_list">
    <columns>
      <!-- column-name name -->
      <column type="gchararray"/>
    </columns>
    <data>
      <row>
        <col id="0" translatable="yes">Novice</col>
      </row>
      <row>
        <col id="0" translatable="yes">Advanced</col>
      </row>
      <row>
        <col id="0" translatable="yes">Expert</col>
      </row>
    </data>
  </object>
  <object class="GtkAdjustment" id="opencl_index_adjustment">
    <property name="lower">-1</property>
    <property name="upper">1000000</property>
    <property name="value">-1</property>
    <property name="step_increment">1</property>
    <property name="page_increment">1</property>
  </object>
  <object class="GtkListStore" id="option_list">
    <columns>
      <!-- column-name name -->
      <column type="gchararray"/>
      <!-- column-name value -->
      <column type="gchararray"/>
    </columns>
  </object>
  <object class="GtkDialog" id="options_dialog">
    <property name="can_focus">False</property>
    <property name="border_width">5</property>
    <property name="title" translatable="yes">Edit Options</property>
    <property name="modal">True</property>
    <property name="window_position">center-on-parent</property>
    <property name="type_hint">normal</property>
    <property name="skip_taskbar_hint">True</property>
    <property name="skip_pager_hint">True</property>
    <property name="transient_for">window</property>
    <signal name="delete-event" handler="on_options_cancel" swapped="no"/>
    <child internal-child="vbox">
      <object class="GtkVBox" id="dialog-vbox4">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="spacing">2</property>
        <child internal-child="action_area">
          <object class="GtkHButtonBox" id="dialog-action_area4">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="layout_style">end</property>
            <child>
              <object class="GtkButton" id="options_ok_button">
                <property name="label">gtk-ok</property>
                <property name="visible">True</property>
                <property name="can_focus">True</property>
                <property name="receives_default">True</property>
                <property name="use_action_appearance">False</property>
                <property name="use_stock">True</property>
                <signal name="clicked" handler="on_options_ok" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="fill">False</property>
                <property name="position">0</property>
              </packing>
            </child>
            <child>
              <object class="GtkButton" id="options_cancel_button">
                <property name="label">gtk-cancel</property>
                <property name="visible">True</property>
                <property name="can_focus">True</property>
                <property name="receives_default">True</property>
                <property name="use_action_appearance">False</property>
                <property name="use_stock">True</property>
                <signal name="clicked" handler="on_options_cancel" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="fill">False</property>
                <property name="position">1</property>
              </packing>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="pack_type">end</property>
            <property name="position">0</property>
          </packing>
        </child>
        <child>
          <object class="GtkFrame" id="frame26">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label_xalign">0</property>
            <child>
              <object class="GtkAlignment" id="alignment32">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="left_padding">12</property>
                <child>
                  <object class="GtkTable" id="table5">
                    <property name="visible">True</property>
                    <property name="can_focus">False</property>
                    <property name="n_rows">2</property>
                    <property name="n_columns">2</property>
                    <child>
                      <object class="GtkLabel" id="label46">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="xpad">4</property>
                        <property name="label" translatable="yes">Name:</property>
                      </object>
                      <packing>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkLabel" id="label47">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="xpad">4</property>
                        <property name="label" translatable="yes">Value:</property>
                      </object>
                      <packing>
                        <property name="top_attach">1</property>
                        <property name="bottom_attach">2</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkEntry" id="option_name_entry">
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="invisible_char">●</property>
                        <property name="primary_icon_activatable">False</property>
                        <property name="secondary_icon_activatable">False</property>
                        <property name="primary_icon_sensitive">True</property>
                        <property name="secondary_icon_sensitive">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkEntry" id="option_value_entry">
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="invisible_char">●</property>
                        <property name="primary_icon_activatable">False</property>
                        <property name="secondary_icon_activatable">False</property>
                        <property name="primary_icon_sensitive">True</property>
                        <property name="secondary_icon_sensitive">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="top_attach">1</property>
                        <property name="bottom_attach">2</property>
                      </packing>
                    </child>
                  </object>
                </child>
              </object>
            </child>
            <child type="label">
              <object class="GtkLabel" id="label48">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="label" translatable="yes">&lt;b&gt;Edit option&lt;/b&gt;</property>
                <property name="use_markup">True</property>
              </object>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">1</property>
          </packing>
        </child>
      </object>
    </child>
    <action-widgets>
      <action-widget response="0">options_ok_button</action-widget>
      <action-widget response="0">options_cancel_button</action-widget>
    </action-widgets>
  </object>
  <object class="GtkMenu" id="osx_tray_menu">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <child>
      <object class="GtkImageMenuItem" id="osx_about_tray_item">
        <property name="label">About FAHControl</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image15</property>
        <property name="use_stock">False</property>
        <signal name="activate" handler="on_about" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkSeparatorMenuItem" id="osx_separator2">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="osx_preferences_tray_item">
        <property name="label">Preferences...</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image10</property>
        <property name="use_stock">False</property>
        <signal name="activate" handler="on_preferences" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkSeparatorMenuItem" id="osx_separator1">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="osx_unpause_tray_item">
        <property name="label" translatable="yes">Fold</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image11</property>
        <property name="use_stock">False</property>
        <signal name="activate" handler="on_unpause" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="osx_pause_tray_item">
        <property name="label">Pause</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image12</property>
        <property name="use_stock">False</property>
        <signal name="activate" handler="on_pause" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="osx_finish_tray_item">
        <property name="label">Finish</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image13</property>
        <property name="use_stock">False</property>
        <signal name="activate" handler="on_finish" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkSeparatorMenuItem" id="osx_separator3">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="osx_viewer_tray_item">
        <property name="label" translatable="yes">Viewer...</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image14</property>
        <property name="use_stock">False</property>
        <signal name="activate" handler="on_viewer" swapped="no"/>
      </object>
    </child>
  </object>
  <object class="GtkAdjustment" id="port_adjustment">
    <property name="upper">65535</property>
    <property name="value">36330</property>
    <property name="step_increment">1</property>
    <property name="page_increment">100</property>
  </object>
  <object class="GtkDialog" id="preferences_dialog">
    <property name="can_focus">False</property>
    <property name="border_width">5</property>
    <property name="title" translatable="yes">Preferences</property>
    <property name="modal">True</property>
    <property name="window_position">center</property>
    <property name="destroy_with_parent">True</property>
    <property name="type_hint">normal</property>
    <property name="skip_taskbar_hint">True</property>
    <property name="skip_pager_hint">True</property>
    <property name="transient_for">window</property>
    <signal name="delete-event" handler="on_preferences_cancel" swapped="no"/>
    <child internal-child="vbox">
      <object class="GtkVBox" id="dialog-vbox1">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="spacing">2</property>
        <child internal-child="action_area">
          <object class="GtkHButtonBox" id="dialog-action_area1">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="layout_style">end</property>
            <child>
              <object class="GtkButton" id="preferences_ok_button">
                <property name="label">gtk-save</property>
                <property name="visible">True</property>
                <property name="can_focus">True</property>
                <property name="receives_default">True</property>
                <property name="use_action_appearance">False</property>
                <property name="use_stock">True</property>
                <signal name="clicked" handler="on_preferences_ok" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="fill">False</property>
                <property name="position">0</property>
              </packing>
            </child>
            <child>
              <object class="GtkButton" id="preferences_cancel_button">
                <property name="label">gtk-cancel</property>
                <property name="visible">True</property>
                <property name="can_focus">True</property>
                <property name="receives_default">True</property>
                <property name="use_action_appearance">False</property>
                <property name="use_stock">True</property>
                <signal name="clicked" handler="on_preferences_cancel" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="fill">False</property>
                <property name="position">1</property>
              </packing>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="pack_type">end</property>
            <property name="position">0</property>
          </packing>
        </child>
        <child>
          <object class="GtkFrame" id="frame43">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label_xalign">0</property>
            <child>
              <object class="GtkAlignment" id="alignment53">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="left_padding">12</property>
                <child>
                  <object class="GtkTable" id="table12">
                    <property name="visible">True</property>
                    <property name="can_focus">False</property>
                    <property name="n_rows">4</property>
                    <property name="n_columns">2</property>
                    <property name="column_spacing">5</property>
                    <child>
                      <object class="GtkCheckButton" id="show_project_in_advanced_pref">
                        <property name="label" translatable="yes">Show Project Info in Advanced</property>
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="receives_default">False</property>
                        <property name="use_action_appearance">False</property>
                        <property name="active">True</property>
                        <property name="draw_indicator">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="top_attach">2</property>
                        <property name="bottom_attach">3</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkLabel" id="theme_label">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="ypad">3</property>
                        <property name="label" translatable="yes">Theme</property>
                        <property name="use_markup">True</property>
                      </object>
                      <packing>
                        <property name="top_attach">3</property>
                        <property name="bottom_attach">4</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkComboBox" id="theme_pref">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="model">theme_list</property>
                        <property name="active">0</property>
                        <signal name="changed" handler="on_theme_pref_changed" swapped="no"/>
                        <child>
                          <object class="GtkCellRendererText" id="cellrenderertext27"/>
                          <attributes>
                            <attribute name="text">0</attribute>
                          </attributes>
                        </child>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="top_attach">3</property>
                        <property name="bottom_attach">4</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkCheckButton" id="minimized_pref">
                        <property name="label" translatable="yes">Start minimized</property>
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="receives_default">False</property>
                        <property name="use_action_appearance">False</property>
                        <property name="active">True</property>
                        <property name="draw_indicator">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkCheckButton" id="quit_on_close_pref">
                        <property name="label" translatable="yes">Quit on window close</property>
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="receives_default">False</property>
                        <property name="use_action_appearance">False</property>
                        <property name="relief">none</property>
                        <property name="draw_indicator">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="top_attach">1</property>
                        <property name="bottom_attach">2</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <placeholder/>
                    </child>
                    <child>
                      <placeholder/>
                    </child>
                    <child>
                      <placeholder/>
                    </child>
                  </object>
                </child>
              </object>
            </child>
            <child type="label">
              <object class="GtkLabel" id="label127">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="label" translatable="yes">&lt;b&gt;User Interface&lt;/b&gt;</property>
                <property name="use_markup">True</property>
              </object>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">1</property>
          </packing>
        </child>
        <child>
          <object class="GtkFrame" id="frame99">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label_xalign">0</property>
            <child>
              <object class="GtkAlignment" id="alignment47">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="left_padding">12</property>
                <child>
                  <object class="GtkTable" id="table11">
                    <property name="visible">True</property>
                    <property name="can_focus">False</property>
                    <property name="n_rows">2</property>
                    <property name="n_columns">2</property>
                    <property name="column_spacing">5</property>
                    <child>
                      <object class="GtkCheckButton" id="autostart_client_pref">
                        <property name="label" translatable="yes">Autostart</property>
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="receives_default">False</property>
                        <property name="use_action_appearance">False</property>
                        <property name="relief">none</property>
                        <property name="xalign">0.52999997138977051</property>
                        <property name="yalign">0.49000000953674316</property>
                        <property name="draw_indicator">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkLabel" id="label112">
                        <property name="width_request">100</property>
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="use_markup">True</property>
                      </object>
                      <packing>
                        <property name="x_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkLabel" id="label94">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="label" translatable="yes">Command</property>
                        <property name="use_markup">True</property>
                      </object>
                      <packing>
                        <property name="top_attach">1</property>
                        <property name="bottom_attach">2</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkEntry" id="client_command_pref">
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="invisible_char">•</property>
                        <property name="text" translatable="yes">FAHClient</property>
                        <property name="primary_icon_activatable">False</property>
                        <property name="secondary_icon_activatable">False</property>
                        <property name="primary_icon_sensitive">True</property>
                        <property name="secondary_icon_sensitive">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="top_attach">1</property>
                        <property name="bottom_attach">2</property>
                      </packing>
                    </child>
                  </object>
                </child>
              </object>
            </child>
            <child type="label">
              <object class="GtkLabel" id="label114">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="label" translatable="yes">&lt;b&gt;Local Client&lt;/b&gt;</property>
                <property name="use_markup">True</property>
              </object>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">2</property>
          </packing>
        </child>
        <child>
          <object class="GtkFrame" id="frame45">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label_xalign">0</property>
            <child>
              <object class="GtkAlignment" id="alignment56">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="left_padding">12</property>
                <child>
                  <object class="GtkTable" id="table16">
                    <property name="visible">True</property>
                    <property name="can_focus">False</property>
                    <property name="n_rows">2</property>
                    <property name="n_columns">3</property>
                    <property name="column_spacing">5</property>
                    <child>
                      <object class="GtkLabel" id="label129">
                        <property name="width_request">100</property>
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="label" translatable="yes">Donor Stats</property>
                        <property name="use_markup">True</property>
                      </object>
                      <packing>
                        <property name="x_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkLabel" id="label130">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="label" translatable="yes">Team Stats</property>
                        <property name="use_markup">True</property>
                      </object>
                      <packing>
                        <property name="top_attach">1</property>
                        <property name="bottom_attach">2</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkEntry" id="donor_stats_pref">
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="tooltip_text" translatable="yes">You can change the link that your browser will go to when you click on your name in the main screen to a custom value by selecting 'Custom' on the right and entering a URL here.

The special values '%(donor)s' and '%(team)s', with out the quotes, will be replaced with your name and team number respectively.</property>
                        <property name="invisible_char">•</property>
                        <property name="invisible_char_set">True</property>
                        <property name="primary_icon_activatable">False</property>
                        <property name="secondary_icon_activatable">False</property>
                        <property name="primary_icon_sensitive">True</property>
                        <property name="secondary_icon_sensitive">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkEntry" id="team_stats_pref">
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="tooltip_text" translatable="yes">You can change the link that your browser will go to when you click on your team number in the main screen to a custom value by selecting 'Custom' on the right and entering a URL here.

The special values '%(donor)s' and '%(team)s', with out the quotes, will be replaced with your name and team number respectively.</property>
                        <property name="invisible_char">•</property>
                        <property name="invisible_char_set">True</property>
                        <property name="primary_icon_activatable">False</property>
                        <property name="secondary_icon_activatable">False</property>
                        <property name="primary_icon_sensitive">True</property>
                        <property name="secondary_icon_sensitive">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="top_attach">1</property>
                        <property name="bottom_attach">2</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkComboBox" id="team_stats_link_pref">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="tooltip_text" translatable="yes">You can change the link that your browser will go to when you click on your team number in the main screen by selecting one of the options in this list.
</property>
                        <property name="model">team_stats_links_list</property>
                        <property name="active">0</property>
                        <signal name="changed" handler="on_team_stats_link_changed" swapped="no"/>
                        <child>
                          <object class="GtkCellRendererText" id="cellrenderertext26"/>
                          <attributes>
                            <attribute name="text">0</attribute>
                          </attributes>
                        </child>
                      </object>
                      <packing>
                        <property name="left_attach">2</property>
                        <property name="right_attach">3</property>
                        <property name="top_attach">1</property>
                        <property name="bottom_attach">2</property>
                        <property name="x_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkComboBox" id="donor_stats_link_pref">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="tooltip_text" translatable="yes">You can change the link that your browser will go to when you click on your name in the main screen by selecting one of the options in this list.
</property>
                        <property name="model">donor_stats_links_list</property>
                        <property name="active">0</property>
                        <signal name="changed" handler="on_donor_stats_link_changed" swapped="no"/>
                        <child>
                          <object class="GtkCellRendererText" id="cellrenderertext13"/>
                          <attributes>
                            <attribute name="text">0</attribute>
                          </attributes>
                        </child>
                      </object>
                      <packing>
                        <property name="left_attach">2</property>
                        <property name="right_attach">3</property>
                        <property name="x_options">GTK_FILL</property>
                      </packing>
                    </child>
                  </object>
                </child>
              </object>
            </child>
            <child type="label">
              <object class="GtkLabel" id="label131">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="label" translatable="yes">&lt;b&gt;Stats Links&lt;/b&gt;</property>
                <property name="use_markup">True</property>
              </object>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">3</property>
          </packing>
        </child>
        <child>
          <object class="GtkFrame" id="frame21">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label_xalign">0</property>
            <child>
              <object class="GtkAlignment" id="alignment28">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="left_padding">12</property>
                <child>
                  <object class="GtkTable" id="table2">
                    <property name="visible">True</property>
                    <property name="can_focus">False</property>
                    <property name="n_rows">5</property>
                    <property name="n_columns">2</property>
                    <property name="column_spacing">5</property>
                    <child>
                      <object class="GtkLabel" id="label105">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="use_markup">True</property>
                      </object>
                      <packing>
                        <property name="top_attach">1</property>
                        <property name="bottom_attach">2</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkLabel" id="label106">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="label" translatable="yes">Screen Width</property>
                        <property name="use_markup">True</property>
                      </object>
                      <packing>
                        <property name="top_attach">2</property>
                        <property name="bottom_attach">3</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkCheckButton" id="viz_fullscreen_pref">
                        <property name="label" translatable="yes">Fullscreen</property>
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="receives_default">False</property>
                        <property name="use_action_appearance">False</property>
                        <property name="image_position">bottom</property>
                        <property name="draw_indicator">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="top_attach">1</property>
                        <property name="bottom_attach">2</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkLabel" id="label108">
                        <property name="width_request">100</property>
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="label" translatable="yes">Command</property>
                        <property name="use_markup">True</property>
                      </object>
                      <packing>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkEntry" id="viz_command_pref">
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="invisible_char">•</property>
                        <property name="text" translatable="yes">FAHViewer</property>
                        <property name="primary_icon_activatable">False</property>
                        <property name="secondary_icon_activatable">False</property>
                        <property name="primary_icon_sensitive">True</property>
                        <property name="secondary_icon_sensitive">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkHBox" id="hbox41">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="spacing">5</property>
                        <child>
                          <object class="GtkSpinButton" id="viz_width_pref">
                            <property name="visible">True</property>
                            <property name="can_focus">True</property>
                            <property name="invisible_char">•</property>
                            <property name="invisible_char_set">True</property>
                            <property name="primary_icon_activatable">False</property>
                            <property name="secondary_icon_activatable">False</property>
                            <property name="primary_icon_sensitive">True</property>
                            <property name="secondary_icon_sensitive">True</property>
                            <property name="adjustment">viz_width_adjustment</property>
                          </object>
                          <packing>
                            <property name="expand">False</property>
                            <property name="fill">True</property>
                            <property name="position">0</property>
                          </packing>
                        </child>
                        <child>
                          <object class="GtkLabel" id="label107">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="xalign">1</property>
                            <property name="label" translatable="yes">Height</property>
                            <property name="use_markup">True</property>
                          </object>
                          <packing>
                            <property name="expand">False</property>
                            <property name="fill">True</property>
                            <property name="position">1</property>
                          </packing>
                        </child>
                        <child>
                          <object class="GtkSpinButton" id="viz_height_pref">
                            <property name="visible">True</property>
                            <property name="can_focus">True</property>
                            <property name="invisible_char">•</property>
                            <property name="invisible_char_set">True</property>
                            <property name="primary_icon_activatable">False</property>
                            <property name="secondary_icon_activatable">False</property>
                            <property name="primary_icon_sensitive">True</property>
                            <property name="secondary_icon_sensitive">True</property>
                            <property name="adjustment">viz_height_adjustment</property>
                          </object>
                          <packing>
                            <property name="expand">False</property>
                            <property name="fill">True</property>
                            <property name="position">2</property>
                          </packing>
                        </child>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="top_attach">2</property>
                        <property name="bottom_attach">3</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkLabel" id="label110">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="label" translatable="yes">Render Mode</property>
                        <property name="use_markup">True</property>
                      </object>
                      <packing>
                        <property name="top_attach">3</property>
                        <property name="bottom_attach">4</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkHBox" id="hbox38">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <child>
                          <object class="GtkComboBox" id="viz_render_mode_pref">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="model">viz_render_mode_liststore</property>
                            <child>
                              <object class="GtkCellRendererText" id="cellrenderertext11"/>
                              <attributes>
                                <attribute name="text">0</attribute>
                              </attributes>
                            </child>
                          </object>
                          <packing>
                            <property name="expand">False</property>
                            <property name="fill">False</property>
                            <property name="position">0</property>
                          </packing>
                        </child>
                        <child>
                          <placeholder/>
                        </child>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="top_attach">3</property>
                        <property name="bottom_attach">4</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkLabel" id="label109">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="xalign">1</property>
                        <property name="use_markup">True</property>
                      </object>
                      <packing>
                        <property name="top_attach">4</property>
                        <property name="bottom_attach">5</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkCheckButton" id="viz_cycle_snapshots_pref">
                        <property name="label" translatable="yes">Cycle Snapshots</property>
                        <property name="visible">True</property>
                        <property name="can_focus">True</property>
                        <property name="receives_default">False</property>
                        <property name="use_action_appearance">False</property>
                        <property name="draw_indicator">True</property>
                      </object>
                      <packing>
                        <property name="left_attach">1</property>
                        <property name="right_attach">2</property>
                        <property name="top_attach">4</property>
                        <property name="bottom_attach">5</property>
                        <property name="x_options">GTK_FILL</property>
                        <property name="y_options">GTK_FILL</property>
                      </packing>
                    </child>
                  </object>
                </child>
              </object>
            </child>
            <child type="label">
              <object class="GtkLabel" id="label104">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="label" translatable="yes">&lt;b&gt;Visualization&lt;/b&gt;</property>
                <property name="use_markup">True</property>
              </object>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">4</property>
          </packing>
        </child>
      </object>
    </child>
    <action-widgets>
      <action-widget response="0">preferences_ok_button</action-widget>
      <action-widget response="0">preferences_cancel_button</action-widget>
    </action-widgets>
  </object>
  <object class="GtkTextBuffer" id="project_text"/>
  <object class="GtkAdjustment" id="proxy_port_adjustment">
    <property name="upper">65535</property>
    <property name="value">8080</property>
    <property name="step_increment">1</property>
    <property name="page_increment">100</property>
  </object>
  <object class="GtkListStore" id="queue_list">
    <columns>
      <!-- column-name unit_id -->
      <column type="gchararray"/>
      <!-- column-name id -->
      <column type="gchararray"/>
      <!-- column-name status -->
      <column type="gchararray"/>
      <!-- column-name status_color -->
      <column type="gchararray"/>
      <!-- column-name progress -->
      <column type="gchararray"/>
      <!-- column-name percent -->
      <column type="gfloat"/>
      <!-- column-name ETA -->
      <column type="gchararray"/>
      <!-- column-name credit -->
      <column type="gchararray"/>
      <!-- column-name PRCG -->
      <column type="gchararray"/>
    </columns>
  </object>
  <object class="GtkDialog" id="slot_dialog">
    <property name="width_request">600</property>
    <property name="height_request">600</property>
    <property name="can_focus">False</property>
    <property name="border_width">5</property>
    <property name="title" translatable="yes">Folding Slot</property>
    <property name="modal">True</property>
    <property name="window_position">center-on-parent</property>
    <property name="type_hint">normal</property>
    <property name="skip_taskbar_hint">True</property>
    <property name="skip_pager_hint">True</property>
    <property name="transient_for">client_dialog</property>
    <signal name="delete-event" handler="on_slot_cancel" swapped="no"/>
    <child internal-child="vbox">
      <object class="GtkVBox" id="dialog-vbox5">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="spacing">2</property>
        <child internal-child="action_area">
          <object class="GtkHButtonBox" id="dialog-action_area5">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="layout_style">end</property>
            <child>
              <object class="GtkButton" id="slot_ok_button">
                <property name="label">gtk-ok</property>
                <property name="visible">True</property>
                <property name="can_focus">True</property>
                <property name="receives_default">True</property>
                <property name="use_action_appearance">False</property>
                <property name="use_stock">True</property>
                <signal name="clicked" handler="on_slot_ok" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="fill">False</property>
                <property name="position">0</property>
              </packing>
            </child>
            <child>
              <object class="GtkButton" id="slot_cancel_button">
                <property name="label">gtk-cancel</property>
                <property name="visible">True</property>
                <property name="can_focus">True</property>
                <property name="receives_default">True</property>
                <property name="use_action_appearance">False</property>
                <property name="use_stock">True</property>
                <signal name="clicked" handler="on_slot_cancel" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="fill">False</property>
                <property name="position">1</property>
              </packing>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="pack_type">end</property>
            <property name="position">0</property>
          </packing>
        </child>
        <child>
          <object class="GtkFrame" id="frame27">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="label_xalign">0</property>
            <property name="shadow_type">none</property>
            <child>
              <object class="GtkAlignment" id="alignment33">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="left_padding">12</property>
                <child>
                  <object class="GtkScrolledWindow" id="scrolledwindow9">
                    <property name="visible">True</property>
                    <property name="can_focus">True</property>
                    <property name="hscrollbar_policy">never</property>
                    <property name="vscrollbar_policy">automatic</property>
                    <child>
                      <object class="GtkViewport" id="viewport9">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <child>
                          <object class="GtkVBox" id="vbox23">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="spacing">2</property>
                            <child>
                              <object class="GtkFrame" id="frame28">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <property name="shadow_type">in</property>
                                <child>
                                  <object class="GtkAlignment" id="alignment34">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="left_padding">12</property>
                                    <child>
                                      <object class="GtkHBox" id="hbox24">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <child>
                                          <object class="GtkRadioButton" id="slot_type_uni">
                                            <property name="visible">True</property>
                                            <property name="can_focus">True</property>
                                            <property name="receives_default">False</property>
                                            <property name="use_action_appearance">False</property>
                                            <property name="active">True</property>
                                            <property name="draw_indicator">True</property>
                                          </object>
                                          <packing>
                                            <property name="expand">False</property>
                                            <property name="fill">True</property>
                                            <property name="position">0</property>
                                          </packing>
                                        </child>
                                        <child>
                                          <object class="GtkLabel" id="wlabel5">
                                            <property name="width_request">1</property>
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="xalign">0</property>
                                            <property name="label" translatable="yes">A uniprocessor slot uses one CPU.</property>
                                          </object>
                                          <packing>
                                            <property name="expand">True</property>
                                            <property name="fill">True</property>
                                            <property name="position">1</property>
                                          </packing>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="label49">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;Uniprocessor&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                              <packing>
                                <property name="expand">False</property>
                                <property name="fill">True</property>
                                <property name="position">0</property>
                              </packing>
                            </child>
                            <child>
                              <object class="GtkFrame" id="frame29">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <property name="shadow_type">in</property>
                                <child>
                                  <object class="GtkAlignment" id="alignment35">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="left_padding">12</property>
                                    <child>
                                      <object class="GtkHBox" id="hbox25">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <child>
                                          <object class="GtkRadioButton" id="slot_type_smp">
                                            <property name="visible">True</property>
                                            <property name="can_focus">True</property>
                                            <property name="receives_default">False</property>
                                            <property name="use_action_appearance">False</property>
                                            <property name="draw_indicator">True</property>
                                            <property name="group">slot_type_uni</property>
                                          </object>
                                          <packing>
                                            <property name="expand">False</property>
                                            <property name="fill">True</property>
                                            <property name="position">0</property>
                                          </packing>
                                        </child>
                                        <child>
                                          <object class="GtkVBox" id="vbox24">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <child>
                                              <object class="GtkLabel" id="wlabel4">
                                                <property name="width_request">1</property>
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="xalign">0</property>
                                                <property name="label" translatable="yes">An SMP slot uses 2 or more CPUs and completes simulation trajectories faster than an equivalent number of uniprocessor slots.</property>
                                              </object>
                                              <packing>
                                                <property name="expand">True</property>
                                                <property name="fill">True</property>
                                                <property name="position">0</property>
                                              </packing>
                                            </child>
                                            <child>
                                              <object class="GtkFrame" id="frame30">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="label_xalign">0</property>
                                                <child>
                                                  <object class="GtkAlignment" id="alignment36">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="left_padding">12</property>
                                                    <child>
                                                      <object class="GtkVBox" id="vbox25">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <child>
                                                          <object class="GtkLabel" id="wlabel3">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="label" translatable="yes">The number of CPU threads this slot should use.  This value should be a multiple of 2.  Leave it as -1 to let the client choose an appropriate default.</property>
                                                          </object>
                                                          <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                          </packing>
                                                        </child>
                                                        <child>
                                                          <object class="GtkHBox" id="hbox26">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <child>
                                                            <object class="GtkSpinButton" id="cpus_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="invisible_char_set">True</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            <property name="adjustment">cpus_adjustment</property>
                                                            <property name="numeric">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">False</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label50">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            </object>
                                                            <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                          <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                          </packing>
                                                        </child>
                                                      </object>
                                                    </child>
                                                  </object>
                                                </child>
                                                <child type="label">
                                                  <object class="GtkLabel" id="label51">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label" translatable="yes">&lt;b&gt;CPUs&lt;/b&gt;</property>
                                                    <property name="use_markup">True</property>
                                                  </object>
                                                </child>
                                              </object>
                                              <packing>
                                                <property name="expand">False</property>
                                                <property name="fill">True</property>
                                                <property name="position">1</property>
                                              </packing>
                                            </child>
                                          </object>
                                          <packing>
                                            <property name="expand">True</property>
                                            <property name="fill">True</property>
                                            <property name="position">1</property>
                                          </packing>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="label52">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;SMP&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                              <packing>
                                <property name="expand">False</property>
                                <property name="fill">True</property>
                                <property name="position">1</property>
                              </packing>
                            </child>
                            <child>
                              <object class="GtkFrame" id="frame31">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <property name="shadow_type">in</property>
                                <child>
                                  <object class="GtkAlignment" id="alignment37">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="left_padding">12</property>
                                    <child>
                                      <object class="GtkHBox" id="hbox27">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <child>
                                          <object class="GtkRadioButton" id="slot_type_gpu">
                                            <property name="visible">True</property>
                                            <property name="can_focus">True</property>
                                            <property name="receives_default">False</property>
                                            <property name="use_action_appearance">False</property>
                                            <property name="draw_indicator">True</property>
                                            <property name="group">slot_type_uni</property>
                                          </object>
                                          <packing>
                                            <property name="expand">False</property>
                                            <property name="fill">True</property>
                                            <property name="position">0</property>
                                          </packing>
                                        </child>
                                        <child>
                                          <object class="GtkVBox" id="vbox26">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <child>
                                              <object class="GtkLabel" id="wlabel1">
                                                <property name="width_request">1</property>
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="xalign">0</property>
                                                <property name="label" translatable="yes">A GPU slot uses the same Graphics Processing Unit that powers 3D applications.  Simulations are usually faster but you must have a supported GPU and the correct drivers installed.</property>
                                              </object>
                                              <packing>
                                                <property name="expand">True</property>
                                                <property name="fill">True</property>
                                                <property name="position">0</property>
                                              </packing>
                                            </child>
                                            <child>
                                              <object class="GtkFrame" id="frame32">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="label_xalign">0</property>
                                                <child>
                                                  <object class="GtkAlignment" id="alignment38">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="left_padding">12</property>
                                                    <child>
                                                      <object class="GtkVBox" id="vbox27">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <child>
                                                          <object class="GtkLabel" id="wlabel2">
                                                            <property name="width_request">1</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="label" translatable="yes">Defines which GPU to use.  The first GPU in the system starts at 0.  Leave this as -1 to allow the client to choose a supported GPU.</property>
                                                          </object>
                                                          <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                          </packing>
                                                        </child>
                                                        <child>
                                                          <object class="GtkTable" id="table4">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="n_columns">3</property>
                                                            <property name="column_spacing">5</property>
                                                            <child>
                                                            <object class="GtkSpinButton" id="gpu_index_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="invisible_char_set">True</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            <property name="adjustment">gpu_index_adjustment</property>
                                                            <property name="numeric">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label2">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;gpu-index&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="x_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label53">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">2</property>
                                                            <property name="right_attach">3</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                          <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                          </packing>
                                                        </child>
                                                      </object>
                                                    </child>
                                                  </object>
                                                </child>
                                                <child type="label">
                                                  <object class="GtkLabel" id="label54">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label" translatable="yes">&lt;b&gt;GPU Index&lt;/b&gt;</property>
                                                    <property name="use_markup">True</property>
                                                  </object>
                                                </child>
                                              </object>
                                              <packing>
                                                <property name="expand">False</property>
                                                <property name="fill">True</property>
                                                <property name="position">1</property>
                                              </packing>
                                            </child>
                                            <child>
                                              <object class="GtkFrame" id="frame5">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="label_xalign">0</property>
                                                <child>
                                                  <object class="GtkAlignment" id="alignment12">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="left_padding">12</property>
                                                    <child>
                                                      <object class="GtkVBox" id="vbox3">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <child>
                                                          <object class="GtkLabel" id="wlabel129">
                                                            <property name="width_request">10</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="label" translatable="yes">Normally it is best to leave these values to their default, -1.  However, in some cases, with system containing multiple GPUs of varying type, the index the client uses to identify the GPU can differ from the index used by the GPU core.  Furthermore, there are two types of GPU core which can used different indices for the same GPU.

If you encounter such a conflict you can try adjusting these values, restarting your GPU slot and then checking, with an appropriate tool, the GPUs activity level.

WARNING, changing these values can make your GPU folding slot fail.</property>
                                                          </object>
                                                          <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">0</property>
                                                          </packing>
                                                        </child>
                                                        <child>
                                                          <object class="GtkTable" id="table14">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="n_rows">2</property>
                                                            <property name="n_columns">3</property>
                                                            <property name="column_spacing">5</property>
                                                            <child>
                                                            <object class="GtkSpinButton" id="opencl_index_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="invisible_char_set">True</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            <property name="adjustment">opencl_index_adjustment</property>
                                                            <property name="numeric">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label78">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;opencl-index&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="x_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label111">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">2</property>
                                                            <property name="right_attach">3</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label120">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">2</property>
                                                            <property name="right_attach">3</property>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkSpinButton" id="cuda_index_option">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="invisible_char">●</property>
                                                            <property name="invisible_char_set">True</property>
                                                            <property name="primary_icon_activatable">False</property>
                                                            <property name="secondary_icon_activatable">False</property>
                                                            <property name="primary_icon_sensitive">True</property>
                                                            <property name="secondary_icon_sensitive">True</property>
                                                            <property name="adjustment">cuda_index_adjustment</property>
                                                            <property name="numeric">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label121">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;cuda-index&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                          </object>
                                                          <packing>
                                                            <property name="expand">True</property>
                                                            <property name="fill">True</property>
                                                            <property name="position">1</property>
                                                          </packing>
                                                        </child>
                                                      </object>
                                                    </child>
                                                  </object>
                                                </child>
                                                <child type="label">
                                                  <object class="GtkLabel" id="label119">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label" translatable="yes">&lt;b&gt;GPU Core Indices (Expert Only)&lt;/b&gt;</property>
                                                    <property name="use_markup">True</property>
                                                  </object>
                                                </child>
                                              </object>
                                              <packing>
                                                <property name="expand">False</property>
                                                <property name="fill">True</property>
                                                <property name="position">2</property>
                                              </packing>
                                            </child>
                                          </object>
                                          <packing>
                                            <property name="expand">True</property>
                                            <property name="fill">True</property>
                                            <property name="position">1</property>
                                          </packing>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="label55">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;GPU&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                              <packing>
                                <property name="expand">False</property>
                                <property name="fill">True</property>
                                <property name="position">2</property>
                              </packing>
                            </child>
                            <child>
                              <object class="GtkFrame" id="frame33">
                                <property name="height_request">150</property>
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <child>
                                  <object class="GtkAlignment" id="alignment39">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="left_padding">12</property>
                                    <child>
                                      <object class="GtkVBox" id="vbox28">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <child>
                                          <object class="GtkScrolledWindow" id="scrolledwindow19">
                                            <property name="visible">True</property>
                                            <property name="can_focus">True</property>
                                            <property name="hscrollbar_policy">automatic</property>
                                            <property name="vscrollbar_policy">automatic</property>
                                            <child>
                                              <object class="GtkViewport" id="viewport16">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="resize_mode">queue</property>
                                                <child>
                                                  <object class="GtkTreeView" id="slot_option_tree_view">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">True</property>
                                                    <property name="model">slot_option_list</property>
                                                    <property name="headers_clickable">False</property>
                                                    <property name="rules_hint">True</property>
                                                    <property name="search_column">0</property>
                                                    <child>
                                                      <object class="GtkTreeViewColumn" id="treeviewcolumn28">
                                                        <property name="title">Name</property>
                                                        <child>
                                                          <object class="GtkCellRendererText" id="slot_option_name_cell">
                                                            <property name="editable">True</property>
                                                          </object>
                                                          <attributes>
                                                            <attribute name="text">0</attribute>
                                                          </attributes>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child>
                                                      <object class="GtkTreeViewColumn" id="treeviewcolumn29">
                                                        <property name="title">Value</property>
                                                        <child>
                                                          <object class="GtkCellRendererText" id="slot_option_value_cell">
                                                            <property name="editable">True</property>
                                                          </object>
                                                          <attributes>
                                                            <attribute name="text">1</attribute>
                                                          </attributes>
                                                        </child>
                                                      </object>
                                                    </child>
                                                  </object>
                                                </child>
                                              </object>
                                            </child>
                                          </object>
                                          <packing>
                                            <property name="expand">True</property>
                                            <property name="fill">True</property>
                                            <property name="position">0</property>
                                          </packing>
                                        </child>
                                        <child>
                                          <object class="GtkHBox" id="hbox29">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <child>
                                              <object class="GtkLabel" id="label56">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                              </object>
                                              <packing>
                                                <property name="expand">True</property>
                                                <property name="fill">True</property>
                                                <property name="position">0</property>
                                              </packing>
                                            </child>
                                            <child>
                                              <object class="GtkHBox" id="hbox30">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <child>
                                                  <object class="GtkButton" id="slot_options_add_button">
                                                    <property name="label">gtk-add</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">True</property>
                                                    <property name="receives_default">True</property>
                                                    <property name="use_action_appearance">False</property>
                                                    <property name="use_stock">True</property>
                                                    <signal name="clicked" handler="on_slot_options_add_button_clicked" swapped="no"/>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">0</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkButton" id="slot_options_remove_button">
                                                    <property name="label">gtk-remove</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">True</property>
                                                    <property name="receives_default">True</property>
                                                    <property name="use_action_appearance">False</property>
                                                    <property name="use_stock">True</property>
                                                    <signal name="clicked" handler="on_slot_options_remove_button_clicked" swapped="no"/>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">1</property>
                                                  </packing>
                                                </child>
                                              </object>
                                              <packing>
                                                <property name="expand">False</property>
                                                <property name="fill">True</property>
                                                <property name="position">1</property>
                                              </packing>
                                            </child>
                                          </object>
                                          <packing>
                                            <property name="expand">False</property>
                                            <property name="fill">True</property>
                                            <property name="position">1</property>
                                          </packing>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="label57">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;Extra slot options (expert only)&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                              <packing>
                                <property name="expand">True</property>
                                <property name="fill">True</property>
                                <property name="position">3</property>
                              </packing>
                            </child>
                          </object>
                        </child>
                      </object>
                    </child>
                  </object>
                </child>
              </object>
            </child>
            <child type="label">
              <object class="GtkLabel" id="label58">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="label" translatable="yes">&lt;b&gt;Configure folding slot&lt;/b&gt;</property>
                <property name="use_markup">True</property>
              </object>
            </child>
          </object>
          <packing>
            <property name="expand">True</property>
            <property name="fill">True</property>
            <property name="position">1</property>
          </packing>
        </child>
      </object>
    </child>
    <action-widgets>
      <action-widget response="0">slot_ok_button</action-widget>
      <action-widget response="0">slot_cancel_button</action-widget>
    </action-widgets>
  </object>
  <object class="GtkListStore" id="slot_list">
    <columns>
      <!-- column-name id -->
      <column type="gint"/>
      <!-- column-name type -->
      <column type="gchararray"/>
      <!-- column-name slot -->
      <column type="GObject"/>
    </columns>
  </object>
  <object class="GtkMenu" id="slot_menu">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <child>
      <object class="GtkImageMenuItem" id="unpause_slot_item">
        <property name="label">Fold</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image2</property>
        <property name="use_stock">False</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_unpause_slot_item_activate" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="pause_slot_item">
        <property name="label">gtk-media-pause</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="use_action_appearance">False</property>
        <property name="use_underline">True</property>
        <property name="use_stock">True</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_pause_slot_item_activate" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="finish_slot_item">
        <property name="label" translatable="yes">Finish</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image1</property>
        <property name="use_stock">False</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_finish_slot_item_activate" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="view_slot_item">
        <property name="label" translatable="yes">Viewer</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="tooltip_text" translatable="yes">View the protein running on this slot.</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image7</property>
        <property name="use_stock">False</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_viewer" swapped="no"/>
      </object>
    </child>
  </object>
  <object class="GtkListStore" id="slot_option_list">
    <columns>
      <!-- column-name name -->
      <column type="gchararray"/>
      <!-- column-name value -->
      <column type="gchararray"/>
    </columns>
  </object>
  <object class="GtkListStore" id="slot_status_list">
    <columns>
      <!-- column-name id -->
      <column type="gchararray"/>
      <!-- column-name status -->
      <column type="gchararray"/>
      <!-- column-name status_color -->
      <column type="gchararray"/>
      <!-- column-name description -->
      <column type="gchararray"/>
    </columns>
  </object>
  <object class="GtkAdjustment" id="status_progress_adjustment">
    <property name="upper">100</property>
    <property name="step_increment">1</property>
    <property name="page_increment">10</property>
  </object>
  <object class="GtkAdjustment" id="team_adjustment">
    <property name="upper">4294967295</property>
    <property name="step_increment">1</property>
    <property name="page_increment">1000</property>
  </object>
  <object class="GtkListStore" id="team_stats_links_list">
    <columns>
      <!-- column-name name -->
      <column type="gchararray"/>
      <!-- column-name url -->
      <column type="gchararray"/>
    </columns>
  </object>
  <object class="GtkTextBuffer" id="textbuffer1">
    <property name="text" translatable="yes">The name, or alias, you enter here will be displayed in the statistics page on our web site.  If you choose not to enter a name, your computer's time will be donated anonymously.  These settings may be changed at any time.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer10">
    <property name="text" translatable="yes">Some cores maintain a maximum checkpoint internal.  A checkpoint saves the core's work so it can restart from the same point later in case the program ends unexpectedly.  This slider lets you control how often these checkpoints occur.  More frequent checkpointing reduces the amount of work that could be lost but decreases performance.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer11">
    <property name="text" translatable="yes">Disable highly optimized assembly code.  Useful if core fails to run because of unsupported instructions.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer12">
    <property name="text" translatable="yes">Try to lock cores to a specific CPU.  Also known as CPU affinity locking.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer13">
    <property name="text" translatable="yes">Pause work while on battery power.  This is useful for laptops.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer14">
    <property name="text" translatable="yes">Set log verbosity level.  Level 0 turns off all but errors and warnings.  Levels 1 to 5 add increasingly more detail to the log.  Level 3 is recommended.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer15">
    <property name="text" translatable="yes">Configure the GUI client's connection to an actual Folding@home client.  The client can either be local or on a remote machine.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer16">
    <property name="text" translatable="yes">Give the client a display name.  "local" client name cannot be changed.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer17">
    <property name="text" translatable="yes">Specify the network address either as an IP of the form ###.###.###.### or a hostname.  "local" client address cannot be changed.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer18">
    <property name="text" translatable="yes">Specify a password for secure access to the client.  This keeps others from being able to control your client remotely, if it is not already protected by a firewall.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer19">
    <property name="text" translatable="yes">The port must match the configuration in the client.  The default port is 36330.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer2">
    <property name="text" translatable="yes">Please check that the name consits of only alphanumeric characters and standard punctuation.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer20">
    <property name="text" translatable="yes">A uniprocessor slot uses one CPU.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer21">
    <property name="text" translatable="yes">An SMP slot uses 2 or more CPUs and completes simulation trajectories faster than an equivalent number of uniprocessor slots.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer22">
    <property name="text" translatable="yes">A GPU slot uses the same Graphics Processing Unit that powers 3D applications.  Simulations are usually faster but you must have a supported GPU and the correct drivers installed.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer23">
    <property name="text" translatable="yes">The number of CPU threads this slot should use.  This value should be a multiple of 2.  Leave it as -1 to let the client choose an appropriate default.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer24">
    <property name="text" translatable="yes">Defines which GPU to use.  The first GPU in the system starts at 0.  Leave this as -1 to allow the client to choose a supported GPU.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer25">
    <property name="text" translatable="yes">These options only have an effect if folding slots are not manually configured below.  They tell the client which slots types it may try to automatically configure.  If enabled the client will first try to configure a GPU slot then an SMP slot and finally a Uniprocessor slot of all else fails.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer26">
    <property name="text" translatable="yes">This application allows you to monitor and control one or more Folding@home version 7 or newer console clients.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer27">
    <property name="text" translatable="yes">If you set a password here clients will be required to enter this password to gain access to the console client.  Otherwise, only clients which are listed in the Passwordless IP Addresses section will be allowed to access this client.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer28">
    <property name="text" translatable="yes">The options in this section can be used to configure remote access to Folding@home clients.  This is mainly only useful to expert users running multiple clients which they would like to monitor and control from another computer.  These options may be safely ignored as the defaults are safe and will not allow any remote access.

In addition to the settings here, you may also have to open access to the configured port in your firewall configuration for the machine or machines which will be allowed to remotely access this client.

Warning, the password set here is transmitted in clear text and is not meant to be a complete security solution.  If you intend to enable access to your Folding@home clients over the Internet then you should use additional security such as secure VPN, SSH tunneling or at a minimum IP based access restriction.

Warning, changes you make here may render your client inaccessible even from the local machine.  If this happens you will have to manually add your IP to 'command-allow' option in the client's 'config.xml' file and restart it.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer29">
    <property name="text" translatable="yes">These fields restrict remote access to the client by allowing and denying IP address ranges.  The client first checks if the IP address matches one of the allowed IP ranges if true access is allowed.  Otherwise, if the IP address is in one  of the deny ranges access is denied.  If the IP address is in neither list access is allowed.

The fields below should contain space separated lists of IP addresses or IP address address ranges which may be specified in one of the two following formats:

  xxx.xxx.xxx.xxx-xxx.xxx.xxx.xxx
or
  xxx.xxx.xxx.xxx/bits

There can be no spaces between the - or / in the above formats.  The first format simply allows all IP addresses counting from the first to the second inclusive.  The second format is shorter and is commonly used in networking software.  The bits field in this format specifies how many bits are signifigant in the range starting from the left.  An IP address has a total of 32 bits.  So the following ranges are equivalent.

  192.168.0.0-192.168.0.255
or
  192.168.0.0/24

The following range specification matches all IP address:

  0.0.0.0/0</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer3">
    <property name="text" translatable="yes">You may also join a team.  If you want your work to count for a team, enter the team number here.  See the Folding@home Web site to find out how to start a team.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer30">
    <property name="text" translatable="yes">These fields accept the same format as above however, the IP address filter created by these fields will allowed to access the client with out a password.

Great care should be taken when modifying these fields.  Normally, only the local IP address 127.0.0.1 should be allowed unless your network is protected by other means and you would like more convenient access to this client.

Addresses listed here also need to be listed above to allow access.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer31">
    <property name="text" translatable="yes">The network port used to access this client.  This must match the port in the configuration used to access this client.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer32">
    <property name="text" translatable="yes">&lt;b&gt;Project Lead&lt;/b&gt;:
  Vijay Pande

Development:
  Joseph Coffland &lt;joseph@cauldrondevelopment.com&gt;

</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer33">
    <property name="text" translatable="yes">This is the configuration for the local client which can be manually started and stopped from here.  A new local client will not be started if one is already running on this address and port.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer34">
    <property name="text" translatable="yes">The hostname or IP address and port of the HTTP proxy.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer35">
    <property name="text" translatable="yes">The proxy user name and password if necessary.  The Folding@home client currently only supports basic and digest authentication.  Specifically NTLM, SOCKS and SSL/TLS proxies are not supported.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer36">
    <property name="text" translatable="yes">Normally it is best to leave these values to their default, -1.  However, in some cases, with system containing multiple GPUs of varying type, the index the client uses to identify the GPU can differ from the index used by the GPU core.  Furthermore, there are two types of GPU core which can used different indices for the same GPU.

If you encounter such a conflict you can try adjusting these values, restarting your GPU slot and then checking, with an appropriate tool, the GPUs activity level.

WARNING, changing these values can make your GPU folding slot fail.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer37">
    <property name="text" translatable="yes">Instruct Folding@home GPU cores to use at most this percentage of the GPU's available processing power.  (80% is recommended)</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer4">
    <property name="text" translatable="yes">For added security, you can request a passkey and enter it here.  This helps to prevent others from pretending to be you.  You are responsible for keeping your passkey a secret.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer5">
    <property name="text" translatable="yes">Changing configuration options in this section may break your client, cost you points, or damage your or your team's standing with the Folding@home project.  Only make changes here if you know what you are doing or have been so instructed by a member of the Folding@home team.

Some of these options may require manually restarting the client to take effect.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer6">
    <property name="text" translatable="yes">If you do not define any folding slots the client will try to choose a good configuration for you automatically.  So you can safely ignore this section.

Folding slots can be one of three types, Uniprocessor, SMP or GPU.  Representing the different types of Folding@home cores.  Expert users can configure many details of each slot but that is usually not necessary.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer7">
    <property name="text" translatable="yes">Lowest possible (recommended)</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer8">
    <property name="text" translatable="yes">Slightly higher.  Use this if other distributed computing applications are stopping Folding@home from running.</property>
  </object>
  <object class="GtkTextBuffer" id="textbuffer9">
    <property name="text" translatable="yes">Instruct Folding@home cores to only use this percentage of the available CPU.  (100% is recommended)</property>
  </object>
  <object class="GtkListStore" id="theme_list">
    <columns>
      <!-- column-name name -->
      <column type="gchararray"/>
      <!-- column-name path -->
      <column type="gchararray"/>
    </columns>
  </object>
  <object class="GtkStatusIcon" id="tray_icon">
    <signal name="activate" handler="on_tray_icon_activate" swapped="no"/>
    <signal name="popup-menu" handler="on_tray_icon_popup_menu" swapped="no"/>
  </object>
  <object class="GtkMenu" id="tray_menu">
    <property name="visible">True</property>
    <property name="can_focus">False</property>
    <signal name="leave-notify-event" handler="on_tray_menu_leave_notify_event" swapped="no"/>
    <signal name="enter-notify-event" handler="on_tray_menu_enter_notify_event" swapped="no"/>
    <child>
      <object class="GtkImageMenuItem" id="restore_tray_item">
        <property name="label" translatable="yes">(Un)Hide Window</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image5</property>
        <property name="use_stock">False</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_restore" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkSeparatorMenuItem" id="separatormenuitem1">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="unpause_tray_item">
        <property name="label" translatable="yes">Fold</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="tooltip_text" translatable="yes">Unpause all paused or finishing clients.</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image3</property>
        <property name="use_stock">False</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_unpause" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="pause_tray_item">
        <property name="label">Pause</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="tooltip_text" translatable="yes">Cause all clients to immediately stop any running cores and go into idle mode until unpaused.</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image6</property>
        <property name="use_stock">False</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_pause" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="finish_tray_item">
        <property name="label">Finish</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="tooltip_text" translatable="yes">Cause all clients to pause as soon as they finish any currently running cores.</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image4</property>
        <property name="use_stock">False</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_finish" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkSeparatorMenuItem" id="separatormenuitem3">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="viewer_tray_item">
        <property name="label" translatable="yes">Viewer</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="tooltip_text" translatable="yes">Start the viewer for the currently selected client and folding slot.</property>
        <property name="use_action_appearance">False</property>
        <property name="image">image8</property>
        <property name="use_stock">False</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_viewer" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="preferences_tray_item">
        <property name="label">gtk-preferences</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="tooltip_text" translatable="yes">Edit FAHControl preferences.</property>
        <property name="use_action_appearance">False</property>
        <property name="use_underline">True</property>
        <property name="use_stock">True</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_preferences" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="about_tray_item">
        <property name="label">gtk-about</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="tooltip_text" translatable="yes">Open the About box.</property>
        <property name="use_action_appearance">False</property>
        <property name="use_underline">True</property>
        <property name="use_stock">True</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_about" swapped="no"/>
      </object>
    </child>
    <child>
      <object class="GtkSeparatorMenuItem" id="separatormenuitem2">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
      </object>
    </child>
    <child>
      <object class="GtkImageMenuItem" id="quit_tray_item">
        <property name="label">gtk-quit</property>
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <property name="tooltip_text" translatable="yes">Quit FAHControl.  The local client will be stopped if it was started by FAHControl.</property>
        <property name="use_action_appearance">False</property>
        <property name="use_underline">True</property>
        <property name="use_stock">True</property>
        <property name="always_show_image">True</property>
        <signal name="activate" handler="on_quit" swapped="no"/>
      </object>
    </child>
  </object>
  <object class="GtkAdjustment" id="verbosity_adjustment">
    <property name="upper">5</property>
    <property name="value">2</property>
    <property name="step_increment">1</property>
  </object>
  <object class="GtkAdjustment" id="viz_height_adjustment">
    <property name="lower">100</property>
    <property name="upper">10000</property>
    <property name="value">600</property>
    <property name="step_increment">1</property>
    <property name="page_increment">10</property>
  </object>
  <object class="GtkListStore" id="viz_render_mode_liststore">
    <columns>
      <!-- column-name name -->
      <column type="gchararray"/>
    </columns>
    <data>
      <row>
        <col id="0" translatable="yes">Space Filling</col>
      </row>
      <row>
        <col id="0" translatable="yes">Ball And Stick</col>
      </row>
      <row>
        <col id="0" translatable="yes">Stick</col>
      </row>
      <row>
        <col id="0" translatable="yes">Cartoon Space Filling</col>
      </row>
      <row>
        <col id="0" translatable="yes">Cartoon Ball And Stick</col>
      </row>
    </data>
  </object>
  <object class="GtkAdjustment" id="viz_width_adjustment">
    <property name="lower">100</property>
    <property name="upper">10000</property>
    <property name="value">800</property>
    <property name="step_increment">1</property>
    <property name="page_increment">10</property>
  </object>
  <object class="GtkWindow" id="window">
    <property name="width_request">820</property>
    <property name="height_request">494</property>
    <property name="can_focus">False</property>
    <property name="title" translatable="yes">FAHControl - Folding@home Client Control</property>
    <property name="window_position">center</property>
    <signal name="destroy-event" handler="on_window_destroy" swapped="no"/>
    <signal name="delete-event" handler="on_window_delete" swapped="no"/>
    <child>
      <object class="GtkVBox" id="vbox1">
        <property name="visible">True</property>
        <property name="can_focus">False</property>
        <child>
          <object class="GtkToolbar" id="toolbar1">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="toolbar_style">both</property>
            <property name="icon_size">1</property>
            <property name="icon_size_set">True</property>
            <child>
              <object class="GtkToolButton" id="configure_button">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="tooltip_text" translatable="yes">Edit currently selected client's configuration.</property>
                <property name="use_action_appearance">False</property>
                <property name="label" translatable="yes">Configure</property>
                <property name="use_underline">True</property>
                <property name="stock_id">gtk-execute</property>
                <signal name="clicked" handler="on_configure" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="homogeneous">True</property>
              </packing>
            </child>
            <child>
              <object class="GtkToolButton" id="preferences_button">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="tooltip_text" translatable="yes">Edit FAHControl preferences.</property>
                <property name="use_action_appearance">False</property>
                <property name="label" translatable="yes">Preferences</property>
                <property name="use_underline">True</property>
                <property name="stock_id">gtk-preferences</property>
                <signal name="clicked" handler="on_preferences" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="homogeneous">True</property>
              </packing>
            </child>
            <child>
              <object class="GtkToolButton" id="unpause_button">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="tooltip_text" translatable="yes">Unpause currently selected paused or finishing client.</property>
                <property name="use_action_appearance">False</property>
                <property name="label" translatable="yes">Fold</property>
                <property name="use_underline">True</property>
                <property name="stock_id">gtk-media-play</property>
                <signal name="clicked" handler="on_unpause" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="homogeneous">True</property>
              </packing>
            </child>
            <child>
              <object class="GtkToolButton" id="pause_button">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="tooltip_text" translatable="yes">Cause currently selected client to immediately stop any running cores and go into idle mode until unpaused.</property>
                <property name="use_action_appearance">False</property>
                <property name="label" translatable="yes">Pause</property>
                <property name="use_underline">True</property>
                <property name="stock_id">gtk-media-pause</property>
                <signal name="clicked" handler="on_pause" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="homogeneous">True</property>
              </packing>
            </child>
            <child>
              <object class="GtkToolButton" id="finish_button">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="tooltip_text" translatable="yes">Cause currently selected client to pause as soon as it finishes any currently running work units.</property>
                <property name="use_action_appearance">False</property>
                <property name="label" translatable="yes">Finish</property>
                <property name="use_underline">True</property>
                <property name="stock_id">gtk-media-next</property>
                <signal name="clicked" handler="on_finish" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="homogeneous">True</property>
              </packing>
            </child>
            <child>
              <object class="GtkToolButton" id="viewer_button">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="tooltip_text" translatable="yes">View protein of the currently selected client and folding slot in 3D.</property>
                <property name="use_action_appearance">False</property>
                <property name="label" translatable="yes">View</property>
                <property name="use_underline">True</property>
                <signal name="clicked" handler="on_viewer" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="homogeneous">True</property>
              </packing>
            </child>
            <child>
              <object class="GtkToolButton" id="hide_button">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="tooltip_text" translatable="yes">Hide FAHControl window.</property>
                <property name="use_action_appearance">False</property>
                <property name="label" translatable="yes">Hide</property>
                <property name="use_underline">True</property>
                <property name="stock_id">gtk-goto-bottom</property>
                <signal name="clicked" handler="on_hide" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="homogeneous">True</property>
              </packing>
            </child>
            <child>
              <object class="GtkToolButton" id="quit_button">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="can_default">True</property>
                <property name="tooltip_text" translatable="yes">Quit FAHControl.  The local client will be stopped if it was started by FAHControl.</property>
                <property name="use_action_appearance">False</property>
                <property name="is_important">True</property>
                <property name="label" translatable="yes">Quit</property>
                <property name="use_underline">True</property>
                <property name="stock_id">gtk-quit</property>
                <signal name="clicked" handler="on_quit" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="homogeneous">True</property>
              </packing>
            </child>
            <child>
              <object class="GtkToolItem" id="toolitem1">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="use_action_appearance">False</property>
                <child>
                  <object class="GtkLabel" id="label38">
                    <property name="visible">True</property>
                    <property name="can_focus">False</property>
                  </object>
                </child>
              </object>
              <packing>
                <property name="expand">True</property>
              </packing>
            </child>
            <child>
              <object class="GtkToolItem" id="toolitem2">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="use_action_appearance">False</property>
                <property name="is_important">True</property>
                <child>
                  <object class="GtkVBox" id="vbox18">
                    <property name="visible">True</property>
                    <property name="can_focus">False</property>
                    <child>
                      <object class="GtkLabel" id="label90">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                      </object>
                      <packing>
                        <property name="expand">True</property>
                        <property name="fill">True</property>
                        <property name="position">0</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkComboBox" id="mode_combo">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="tooltip_text" translatable="yes">Change interface mode.   The mode affects which status and configuration panels are present.</property>
                        <property name="model">mode_list</property>
                        <property name="active">0</property>
                        <signal name="changed" handler="on_mode_changed" swapped="no"/>
                        <child>
                          <object class="GtkCellRendererText" id="cellrenderertext25"/>
                          <attributes>
                            <attribute name="text">0</attribute>
                          </attributes>
                        </child>
                      </object>
                      <packing>
                        <property name="expand">False</property>
                        <property name="fill">True</property>
                        <property name="position">1</property>
                      </packing>
                    </child>
                    <child>
                      <object class="GtkLabel" id="label76">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                      </object>
                      <packing>
                        <property name="expand">True</property>
                        <property name="fill">True</property>
                        <property name="position">2</property>
                      </packing>
                    </child>
                  </object>
                </child>
              </object>
              <packing>
                <property name="expand">False</property>
              </packing>
            </child>
            <child>
              <object class="GtkToolButton" id="about_button">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="tooltip_text" translatable="yes">Open the About box.</property>
                <property name="use_action_appearance">False</property>
                <property name="label" translatable="yes">About</property>
                <property name="use_underline">True</property>
                <property name="stock_id">gtk-about</property>
                <signal name="clicked" handler="on_about" swapped="no"/>
              </object>
              <packing>
                <property name="expand">False</property>
                <property name="homogeneous">True</property>
              </packing>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="position">0</property>
          </packing>
        </child>
        <child>
          <object class="GtkHPaned" id="client_hpaned">
            <property name="visible">True</property>
            <property name="can_focus">True</property>
            <property name="position">220</property>
            <property name="position_set">True</property>
            <child>
              <object class="GtkAlignment" id="advanced_clients">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="bottom_padding">4</property>
                <property name="left_padding">4</property>
                <property name="right_padding">4</property>
                <child>
                  <object class="GtkFrame" id="frame1">
                    <property name="visible">True</property>
                    <property name="can_focus">False</property>
                    <property name="label_xalign">0</property>
                    <child>
                      <object class="GtkAlignment" id="alignment6">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <child>
                          <object class="GtkVBox" id="vbox2">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <child>
                              <object class="GtkScrolledWindow" id="scrolledwindow1">
                                <property name="visible">True</property>
                                <property name="can_focus">True</property>
                                <property name="hscrollbar_policy">automatic</property>
                                <property name="vscrollbar_policy">automatic</property>
                                <child>
                                  <object class="GtkViewport" id="viewport2">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="resize_mode">queue</property>
                                    <child>
                                      <object class="GtkTreeView" id="client_tree_view">
                                        <property name="visible">True</property>
                                        <property name="can_focus">True</property>
                                        <property name="tooltip_text" translatable="yes">List of connected Folding@home clients.</property>
                                        <property name="model">client_list</property>
                                        <property name="headers_clickable">False</property>
                                        <property name="rules_hint">True</property>
                                        <property name="search_column">0</property>
                                        <signal name="row-activated" handler="on_client_tree_view_row_activated" swapped="no"/>
                                        <child>
                                          <object class="GtkTreeViewColumn" id="treeviewcolumn1">
                                            <property name="title">Name</property>
                                            <child>
                                              <object class="GtkCellRendererText" id="cellrenderertext1"/>
                                              <attributes>
                                                <attribute name="text">0</attribute>
                                              </attributes>
                                            </child>
                                          </object>
                                        </child>
                                        <child>
                                          <object class="GtkTreeViewColumn" id="treeviewcolumn22">
                                            <property name="title">Status</property>
                                            <child>
                                              <object class="GtkCellRendererText" id="cellrenderertext2"/>
                                              <attributes>
                                                <attribute name="background">2</attribute>
                                                <attribute name="text">1</attribute>
                                              </attributes>
                                            </child>
                                          </object>
                                        </child>
                                        <child>
                                          <object class="GtkTreeViewColumn" id="treeviewcolumn23">
                                            <property name="title">Address</property>
                                            <child>
                                              <object class="GtkCellRendererText" id="cellrenderertext3">
                                                <property name="xalign">0</property>
                                              </object>
                                              <attributes>
                                                <attribute name="text">3</attribute>
                                              </attributes>
                                            </child>
                                          </object>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                              </object>
                              <packing>
                                <property name="expand">True</property>
                                <property name="fill">True</property>
                                <property name="position">0</property>
                              </packing>
                            </child>
                            <child>
                              <object class="GtkHBox" id="hbox1">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <child>
                                  <object class="GtkLabel" id="label18">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                  </object>
                                  <packing>
                                    <property name="expand">True</property>
                                    <property name="fill">True</property>
                                    <property name="position">0</property>
                                  </packing>
                                </child>
                                <child>
                                  <object class="GtkHBox" id="hbox2">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <child>
                                      <object class="GtkButton" id="client_add_button">
                                        <property name="label">gtk-add</property>
                                        <property name="visible">True</property>
                                        <property name="can_focus">True</property>
                                        <property name="receives_default">True</property>
                                        <property name="tooltip_text" translatable="yes">Add a new client configuration.</property>
                                        <property name="use_action_appearance">False</property>
                                        <property name="use_stock">True</property>
                                        <signal name="clicked" handler="on_client_add_button_clicked" swapped="no"/>
                                      </object>
                                      <packing>
                                        <property name="expand">False</property>
                                        <property name="fill">True</property>
                                        <property name="position">0</property>
                                      </packing>
                                    </child>
                                    <child>
                                      <object class="GtkButton" id="client_remove_button">
                                        <property name="label">gtk-remove</property>
                                        <property name="visible">True</property>
                                        <property name="can_focus">True</property>
                                        <property name="receives_default">True</property>
                                        <property name="tooltip_text" translatable="yes">Remove selected client configuration.</property>
                                        <property name="use_action_appearance">False</property>
                                        <property name="use_stock">True</property>
                                        <signal name="clicked" handler="on_client_remove_button_clicked" swapped="no"/>
                                      </object>
                                      <packing>
                                        <property name="expand">False</property>
                                        <property name="fill">True</property>
                                        <property name="position">1</property>
                                      </packing>
                                    </child>
                                  </object>
                                  <packing>
                                    <property name="expand">False</property>
                                    <property name="fill">True</property>
                                    <property name="position">1</property>
                                  </packing>
                                </child>
                              </object>
                              <packing>
                                <property name="expand">False</property>
                                <property name="fill">True</property>
                                <property name="position">1</property>
                              </packing>
                            </child>
                          </object>
                        </child>
                      </object>
                    </child>
                    <child type="label">
                      <object class="GtkLabel" id="label1">
                        <property name="visible">True</property>
                        <property name="can_focus">False</property>
                        <property name="label" translatable="yes">&lt;b&gt;Clients&lt;/b&gt;</property>
                        <property name="use_markup">True</property>
                      </object>
                    </child>
                  </object>
                </child>
              </object>
              <packing>
                <property name="resize">False</property>
                <property name="shrink">True</property>
              </packing>
            </child>
            <child>
              <object class="GtkFrame" id="frame2">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="label_xalign">0</property>
                <child>
                  <object class="GtkAlignment" id="alignment3">
                    <property name="visible">True</property>
                    <property name="can_focus">False</property>
                    <property name="bottom_padding">4</property>
                    <property name="left_padding">4</property>
                    <property name="right_padding">4</property>
                    <child>
                      <object class="GtkNotebook" id="client_notebook">
                        <property name="visible">True</property>
                        <property name="sensitive">False</property>
                        <property name="can_focus">True</property>
                        <child>
                          <object class="GtkVPaned" id="project_vpaned">
                            <property name="visible">True</property>
                            <property name="can_focus">True</property>
                            <property name="position">200</property>
                            <property name="position_set">True</property>
                            <child>
                              <object class="GtkAlignment" id="status_tab">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="top_padding">4</property>
                                <property name="bottom_padding">4</property>
                                <property name="left_padding">4</property>
                                <property name="right_padding">4</property>
                                <child>
                                  <object class="GtkVBox" id="vbox29">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <child>
                                      <object class="GtkHBox" id="hbox13">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <property name="spacing">5</property>
                                        <child>
                                          <object class="GtkFrame" id="frame3">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="label_xalign">0</property>
                                            <child>
                                              <object class="GtkAlignment" id="alignment4">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="left_padding">12</property>
                                                <child>
                                                  <object class="GtkHBox" id="hbox39">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <child>
                                                      <object class="GtkLabel" id="label12">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="xalign">1</property>
                                                        <property name="xpad">3</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Name&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">False</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">0</property>
                                                      </packing>
                                                    </child>
                                                    <child>
                                                      <object class="GtkLinkButton" id="donor_info">
                                                        <property name="label" translatable="yes">Anonymous</property>
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">True</property>
                                                        <property name="can_default">True</property>
                                                        <property name="receives_default">True</property>
                                                        <property name="tooltip_text" translatable="yes">This client's configured Folding@home user name.</property>
                                                        <property name="use_action_appearance">False</property>
                                                        <property name="relief">none</property>
                                                        <property name="xalign">0</property>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">True</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">1</property>
                                                      </packing>
                                                    </child>
                                                    <child>
                                                      <object class="GtkLabel" id="label13">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="xalign">1</property>
                                                        <property name="xpad">3</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Team&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">False</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">2</property>
                                                      </packing>
                                                    </child>
                                                    <child>
                                                      <object class="GtkLinkButton" id="team_info">
                                                        <property name="label" translatable="yes">0</property>
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">True</property>
                                                        <property name="can_default">True</property>
                                                        <property name="receives_default">True</property>
                                                        <property name="tooltip_text" translatable="yes">This client's configured Folding@home team number.</property>
                                                        <property name="use_action_appearance">False</property>
                                                        <property name="relief">none</property>
                                                        <property name="xalign">0</property>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">False</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">3</property>
                                                      </packing>
                                                    </child>
                                                  </object>
                                                </child>
                                              </object>
                                            </child>
                                            <child type="label">
                                              <object class="GtkLabel" id="label9">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="label" translatable="yes">&lt;b&gt;Identity&lt;/b&gt;</property>
                                                <property name="use_markup">True</property>
                                              </object>
                                            </child>
                                          </object>
                                          <packing>
                                            <property name="expand">False</property>
                                            <property name="fill">True</property>
                                            <property name="position">0</property>
                                          </packing>
                                        </child>
                                        <child>
                                          <object class="GtkFrame" id="frame46">
                                            <property name="width_request">140</property>
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="label_xalign">0</property>
                                            <child>
                                              <object class="GtkAlignment" id="alignment57">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="left_padding">12</property>
                                                <child>
                                                  <object class="GtkHBox" id="hbox28">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="spacing">5</property>
                                                    <child>
                                                      <object class="GtkLabel" id="label66">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="tooltip_text" translatable="yes">Total estimated Points Per Day for this client.</property>
                                                        <property name="xalign">1</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;PPD&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">False</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">0</property>
                                                      </packing>
                                                    </child>
                                                    <child>
                                                      <object class="GtkLabel" id="client_ppd">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="xalign">0</property>
                                                        <property name="label" translatable="yes">Unknown</property>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">False</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">1</property>
                                                      </packing>
                                                    </child>
                                                  </object>
                                                </child>
                                              </object>
                                            </child>
                                            <child type="label">
                                              <object class="GtkLabel" id="label21">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="label" translatable="yes">&lt;b&gt;Stats&lt;/b&gt;</property>
                                                <property name="use_markup">True</property>
                                              </object>
                                            </child>
                                          </object>
                                          <packing>
                                            <property name="expand">False</property>
                                            <property name="fill">True</property>
                                            <property name="position">1</property>
                                          </packing>
                                        </child>
                                      </object>
                                      <packing>
                                        <property name="expand">False</property>
                                        <property name="fill">True</property>
                                        <property name="position">0</property>
                                      </packing>
                                    </child>
                                    <child>
                                      <object class="GtkAlignment" id="alignment13">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <child>
                                          <object class="GtkHPaned" id="status_hpaned">
                                            <property name="visible">True</property>
                                            <property name="can_focus">True</property>
                                            <property name="position">200</property>
                                            <property name="position_set">True</property>
                                            <child>
                                              <object class="GtkVPaned" id="status_vpaned">
                                                <property name="visible">True</property>
                                                <property name="can_focus">True</property>
                                                <property name="position">150</property>
                                                <property name="position_set">True</property>
                                                <child>
                                                  <object class="GtkFrame" id="advanced_slots_frame">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment5">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <child>
                                                          <object class="GtkScrolledWindow" id="scrolledwindow10">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="hscrollbar_policy">automatic</property>
                                                            <property name="vscrollbar_policy">automatic</property>
                                                            <child>
                                                            <object class="GtkViewport" id="viewport10">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="resize_mode">queue</property>
                                                            <child>
                                                            <object class="GtkTreeView" id="slot_status_tree_view">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="tooltip_text" translatable="yes">List of folding slots on this client.</property>
                                                            <property name="model">slot_status_list</property>
                                                            <property name="headers_clickable">False</property>
                                                            <property name="search_column">0</property>
                                                            <signal name="button-press-event" handler="on_slot_status_tree_view_button_press_event" swapped="no"/>
                                                            <signal name="cursor-changed" handler="on_slot_status_tree_cursor_changed" swapped="no"/>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="treeviewcolumn25">
                                                            <property name="title">ID</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="cellrenderertext19">
                                                            <property name="xalign">1</property>
                                                            </object>
                                                            <attributes>
                                                            <attribute name="text">0</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="treeviewcolumn27">
                                                            <property name="title">Status</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="cellrenderertext21"/>
                                                            <attributes>
                                                            <attribute name="cell-background">2</attribute>
                                                            <attribute name="background">2</attribute>
                                                            <attribute name="text">1</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="treeviewcolumn26">
                                                            <property name="title">Description</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="cellrenderertext20"/>
                                                            <attributes>
                                                            <attribute name="text">3</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label14">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Folding Slots&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="resize">False</property>
                                                    <property name="shrink">True</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkFrame" id="queue_frame">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label_xalign">0</property>
                                                    <child>
                                                      <object class="GtkAlignment" id="alignment7">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <child>
                                                          <object class="GtkScrolledWindow" id="scrolledwindow3">
                                                            <property name="width_request">200</property>
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="hscrollbar_policy">automatic</property>
                                                            <property name="vscrollbar_policy">automatic</property>
                                                            <property name="shadow_type">etched-in</property>
                                                            <child>
                                                            <object class="GtkTreeView" id="queue_tree">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="tooltip_text" translatable="yes">List of work units on this client.</property>
                                                            <property name="model">queue_list</property>
                                                            <property name="headers_clickable">False</property>
                                                            <property name="search_column">0</property>
                                                            <signal name="cursor-changed" handler="on_queue_tree_cursor_changed" swapped="no"/>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="queue_id_treeviewcolumn">
                                                            <property name="title">ID</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="cellrenderertext4"/>
                                                            <attributes>
                                                            <attribute name="text">1</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="queue_status_treeviewcolumn">
                                                            <property name="title">Status</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="cellrenderertext5"/>
                                                            <attributes>
                                                            <attribute name="background">3</attribute>
                                                            <attribute name="text">2</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="queue_progress_treeviewcolumn">
                                                            <property name="title">Progress</property>
                                                            <child>
                                                            <object class="GtkCellRendererProgress" id="cellrendererprogress1">
                                                            <property name="width">100</property>
                                                            </object>
                                                            <attributes>
                                                            <attribute name="text">4</attribute>
                                                            <attribute name="value">5</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="queue_eta_treeviewcolumn">
                                                            <property name="title">ETA</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="cellrenderertext6"/>
                                                            <attributes>
                                                            <attribute name="text">6</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="queue_credit_treeviewcolumn">
                                                            <property name="title">Credit</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="cellrenderertext9"/>
                                                            <attributes>
                                                            <attribute name="text">7</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            <child>
                                                            <object class="GtkTreeViewColumn" id="queue_prcg_treeviewcolumn">
                                                            <property name="title">PRCG</property>
                                                            <child>
                                                            <object class="GtkCellRendererText" id="cellrenderertext10"/>
                                                            <attributes>
                                                            <attribute name="text">8</attribute>
                                                            </attributes>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                    <child type="label">
                                                      <object class="GtkLabel" id="label11">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="label" translatable="yes">&lt;b&gt;Work Queue&lt;/b&gt;</property>
                                                        <property name="use_markup">True</property>
                                                      </object>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="resize">True</property>
                                                    <property name="shrink">True</property>
                                                  </packing>
                                                </child>
                                              </object>
                                              <packing>
                                                <property name="resize">False</property>
                                                <property name="shrink">True</property>
                                              </packing>
                                            </child>
                                            <child>
                                              <object class="GtkFrame" id="advanced_unit_frame">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="label_xalign">0</property>
                                                <child>
                                                  <object class="GtkAlignment" id="alignment27">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <child>
                                                      <object class="GtkScrolledWindow" id="scrolledwindow16">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">True</property>
                                                        <property name="hscrollbar_policy">automatic</property>
                                                        <property name="vscrollbar_policy">automatic</property>
                                                        <child>
                                                          <object class="GtkViewport" id="viewport4">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="resize_mode">queue</property>
                                                            <property name="shadow_type">none</property>
                                                            <child>
                                                            <object class="GtkAlignment" id="alignment46">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="top_padding">4</property>
                                                            <property name="bottom_padding">4</property>
                                                            <property name="left_padding">4</property>
                                                            <property name="right_padding">4</property>
                                                            <child>
                                                            <object class="GtkTable" id="table10">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="n_rows">20</property>
                                                            <property name="n_columns">2</property>
                                                            <property name="column_spacing">4</property>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_core">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">11</property>
                                                            <property name="bottom_attach">12</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_assigned">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">15</property>
                                                            <property name="bottom_attach">16</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_deadline">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">17</property>
                                                            <property name="bottom_attach">18</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_id">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">2</property>
                                                            <property name="bottom_attach">3</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_state">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">3</property>
                                                            <property name="bottom_attach">4</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkProgressBar" id="queue_percentdone">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">4</property>
                                                            <property name="bottom_attach">5</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLinkButton" id="queue_ws">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="relief">none</property>
                                                            <property name="focus_on_click">False</property>
                                                            <property name="xalign">0</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">18</property>
                                                            <property name="bottom_attach">19</property>
                                                            <property name="y_options"></property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLinkButton" id="queue_cs">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="relief">none</property>
                                                            <property name="focus_on_click">False</property>
                                                            <property name="xalign">0</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">19</property>
                                                            <property name="bottom_attach">20</property>
                                                            <property name="y_options"></property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label40">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">Folding core ID.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;FahCore&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">11</property>
                                                            <property name="bottom_attach">12</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label86">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">UTC time this work unit was assigned.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Assigned&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">15</property>
                                                            <property name="bottom_attach">16</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label88">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">Final deadline for this work unit.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Expiration&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">17</property>
                                                            <property name="bottom_attach">18</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label96">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Work Queue ID&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">2</property>
                                                            <property name="bottom_attach">3</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label97">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Status&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">3</property>
                                                            <property name="bottom_attach">4</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label98">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Progress&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">4</property>
                                                            <property name="bottom_attach">5</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label83">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">The work server this work unit belongs to.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Work Server&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">18</property>
                                                            <property name="bottom_attach">19</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label84">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">The alternative upload server for this work unit.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Collection Server&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">19</property>
                                                            <property name="bottom_attach">20</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLinkButton" id="queue_project">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">True</property>
                                                            <property name="receives_default">True</property>
                                                            <property name="use_action_appearance">False</property>
                                                            <property name="relief">none</property>
                                                            <property name="focus_on_click">False</property>
                                                            <property name="xalign">0</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">10</property>
                                                            <property name="bottom_attach">11</property>
                                                            <property name="y_options"></property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label8">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">The Folding@home project this work unit belongs to.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Project&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">10</property>
                                                            <property name="bottom_attach">11</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label100">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">What this folding slot is waiting on.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Waiting On&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">12</property>
                                                            <property name="bottom_attach">13</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_waitingon">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">12</property>
                                                            <property name="bottom_attach">13</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label102">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">Number of attempts at the current operation.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Attempts&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">13</property>
                                                            <property name="bottom_attach">14</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_attempts">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">13</property>
                                                            <property name="bottom_attach">14</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label101">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">Next time this work unit will retry the failed operation.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Next Attempt&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">14</property>
                                                            <property name="bottom_attach">15</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_nextattempt">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">14</property>
                                                            <property name="bottom_attach">15</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label7">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">Estimated time until the work unit is completed.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;ETA&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">5</property>
                                                            <property name="bottom_attach">6</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label77">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">Points wo/ bonus.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Base Credit&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">6</property>
                                                            <property name="bottom_attach">7</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label82">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">Estimated Points Per Day</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Estimated PPD&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">8</property>
                                                            <property name="bottom_attach">9</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_ppd">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">8</property>
                                                            <property name="bottom_attach">9</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_basecredit">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">6</property>
                                                            <property name="bottom_attach">7</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_eta">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">5</property>
                                                            <property name="bottom_attach">6</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label87">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">UTC prefered deadline for this work unit.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Timeout&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">16</property>
                                                            <property name="bottom_attach">17</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_timeout">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">16</property>
                                                            <property name="bottom_attach">17</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label6">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">Project Run Clone Gen</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;PRCG&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_prcg">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label16">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Folding Slot ID&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_slot">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">1</property>
                                                            <property name="bottom_attach">2</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label59">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">Estimated Time Per Frame.   A frame is 1% of the work unit.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Estimated TPF&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">9</property>
                                                            <property name="bottom_attach">10</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_tpf">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">9</property>
                                                            <property name="bottom_attach">10</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="label92">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="tooltip_text" translatable="yes">Points with estimated  bonus.</property>
                                                            <property name="xalign">1</property>
                                                            <property name="label" translatable="yes">&lt;b&gt;Estimated Credit&lt;/b&gt;</property>
                                                            <property name="use_markup">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="top_attach">7</property>
                                                            <property name="bottom_attach">8</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            <child>
                                                            <object class="GtkLabel" id="queue_creditestimate">
                                                            <property name="visible">True</property>
                                                            <property name="can_focus">False</property>
                                                            <property name="xalign">0</property>
                                                            <property name="use_markup">True</property>
                                                            <property name="selectable">True</property>
                                                            </object>
                                                            <packing>
                                                            <property name="left_attach">1</property>
                                                            <property name="right_attach">2</property>
                                                            <property name="top_attach">7</property>
                                                            <property name="bottom_attach">8</property>
                                                            <property name="x_options">GTK_FILL</property>
                                                            <property name="y_options">GTK_FILL</property>
                                                            </packing>
                                                            </child>
                                                            </object>
                                                            </child>
                                                            </object>
                                                            </child>
                                                          </object>
                                                        </child>
                                                      </object>
                                                    </child>
                                                  </object>
                                                </child>
                                                <child type="label">
                                                  <object class="GtkLabel" id="label4">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="label" translatable="yes">&lt;b&gt;Work Unit&lt;/b&gt;</property>
                                                    <property name="use_markup">True</property>
                                                  </object>
                                                </child>
                                              </object>
                                              <packing>
                                                <property name="resize">True</property>
                                                <property name="shrink">True</property>
                                              </packing>
                                            </child>
                                          </object>
                                        </child>
                                      </object>
                                      <packing>
                                        <property name="expand">True</property>
                                        <property name="fill">True</property>
                                        <property name="position">1</property>
                                      </packing>
                                    </child>
                                  </object>
                                </child>
                              </object>
                              <packing>
                                <property name="resize">False</property>
                                <property name="shrink">True</property>
                              </packing>
                            </child>
                            <child>
                              <object class="GtkFrame" id="novice_project_frame">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="label_xalign">0</property>
                                <child>
                                  <object class="GtkAlignment" id="alignment52">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <child>
                                      <object class="GtkScrolledWindow" id="scrolledwindow18">
                                        <property name="visible">True</property>
                                        <property name="can_focus">True</property>
                                        <property name="hscrollbar_policy">automatic</property>
                                        <property name="vscrollbar_policy">automatic</property>
                                        <child>
                                          <object class="GtkTextView" id="textview106">
                                            <property name="visible">True</property>
                                            <property name="sensitive">False</property>
                                            <property name="can_focus">True</property>
                                            <property name="tooltip_text" translatable="yes">Project description for the currently selected work unit.</property>
                                            <property name="editable">False</property>
                                            <property name="wrap_mode">word</property>
                                            <property name="cursor_visible">False</property>
                                            <property name="buffer">project_text</property>
                                          </object>
                                        </child>
                                      </object>
                                    </child>
                                  </object>
                                </child>
                                <child type="label">
                                  <object class="GtkLabel" id="project_label">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="label" translatable="yes">&lt;b&gt;Project:&lt;/b&gt;</property>
                                    <property name="use_markup">True</property>
                                  </object>
                                </child>
                              </object>
                              <packing>
                                <property name="resize">True</property>
                                <property name="shrink">True</property>
                              </packing>
                            </child>
                          </object>
                        </child>
                        <child type="tab">
                          <object class="GtkLabel" id="status_tab_label">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="label" translatable="yes">Status</property>
                          </object>
                          <packing>
                            <property name="tab_fill">False</property>
                          </packing>
                        </child>
                        <child>
                          <object class="GtkScrolledWindow" id="advanced_info_tab">
                            <property name="visible">True</property>
                            <property name="can_focus">True</property>
                            <property name="hscrollbar_policy">automatic</property>
                            <property name="vscrollbar_policy">automatic</property>
                            <child>
                              <object class="GtkViewport" id="info_view_port">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <property name="tooltip_text" translatable="yes">Information about the currently selected folding client.</property>
                                <property name="resize_mode">queue</property>
                                <child>
                                  <object class="GtkAlignment" id="info_alignment">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <property name="top_padding">4</property>
                                    <property name="bottom_padding">4</property>
                                    <property name="left_padding">4</property>
                                    <property name="right_padding">4</property>
                                    <child>
                                      <placeholder/>
                                    </child>
                                  </object>
                                </child>
                              </object>
                            </child>
                          </object>
                          <packing>
                            <property name="position">1</property>
                          </packing>
                        </child>
                        <child type="tab">
                          <object class="GtkLabel" id="info_tab_label">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="label" translatable="yes">System Info</property>
                          </object>
                          <packing>
                            <property name="position">1</property>
                            <property name="tab_fill">False</property>
                          </packing>
                        </child>
                        <child>
                          <object class="GtkAlignment" id="advanced_log_tab">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <child>
                              <object class="GtkVBox" id="vbox40">
                                <property name="visible">True</property>
                                <property name="can_focus">False</property>
                                <child>
                                  <object class="GtkHBox" id="hbox16">
                                    <property name="visible">True</property>
                                    <property name="can_focus">False</property>
                                    <child>
                                      <object class="GtkFrame" id="log_filters_advanced">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <property name="label_xalign">0</property>
                                        <child>
                                          <object class="GtkAlignment" id="alignment55">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="left_padding">12</property>
                                            <child>
                                              <object class="GtkHBox" id="hbox10">
                                                <property name="visible">True</property>
                                                <property name="can_focus">False</property>
                                                <property name="spacing">10</property>
                                                <child>
                                                  <object class="GtkCheckButton" id="log_severity">
                                                    <property name="label" translatable="yes">Warnings &amp; Errors</property>
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">True</property>
                                                    <property name="receives_default">False</property>
                                                    <property name="use_action_appearance">False</property>
                                                    <property name="draw_indicator">True</property>
                                                    <signal name="toggled" handler="on_update_log" swapped="no"/>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">True</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">0</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkHBox" id="hbox14">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="spacing">5</property>
                                                    <child>
                                                      <object class="GtkCheckButton" id="log_slot_enable">
                                                        <property name="label" translatable="yes">Slot:</property>
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="receives_default">False</property>
                                                        <property name="use_action_appearance">False</property>
                                                        <property name="draw_indicator">True</property>
                                                        <signal name="toggled" handler="on_update_log" swapped="no"/>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">False</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">0</property>
                                                      </packing>
                                                    </child>
                                                    <child>
                                                      <object class="GtkComboBox" id="log_slot">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="model">slot_status_list</property>
                                                        <property name="column_span_column">0</property>
                                                        <property name="button_sensitivity">on</property>
                                                        <signal name="changed" handler="on_update_log" swapped="no"/>
                                                        <child>
                                                          <object class="GtkCellRendererText" id="cellrenderertext8"/>
                                                          <attributes>
                                                            <attribute name="text">0</attribute>
                                                          </attributes>
                                                        </child>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">False</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">1</property>
                                                      </packing>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">1</property>
                                                  </packing>
                                                </child>
                                                <child>
                                                  <object class="GtkHBox" id="hbox15">
                                                    <property name="visible">True</property>
                                                    <property name="can_focus">False</property>
                                                    <property name="spacing">5</property>
                                                    <child>
                                                      <object class="GtkCheckButton" id="log_unit_enable">
                                                        <property name="label" translatable="yes">Unit:</property>
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="receives_default">False</property>
                                                        <property name="use_action_appearance">False</property>
                                                        <property name="draw_indicator">True</property>
                                                        <signal name="toggled" handler="on_update_log" swapped="no"/>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">False</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">0</property>
                                                      </packing>
                                                    </child>
                                                    <child>
                                                      <object class="GtkComboBox" id="log_unit">
                                                        <property name="visible">True</property>
                                                        <property name="can_focus">False</property>
                                                        <property name="model">queue_list</property>
                                                        <property name="column_span_column">0</property>
                                                        <property name="button_sensitivity">on</property>
                                                        <signal name="changed" handler="on_update_log" swapped="no"/>
                                                        <child>
                                                          <object class="GtkCellRendererText" id="cellrenderertext12"/>
                                                          <attributes>
                                                            <attribute name="text">1</attribute>
                                                          </attributes>
                                                        </child>
                                                      </object>
                                                      <packing>
                                                        <property name="expand">False</property>
                                                        <property name="fill">True</property>
                                                        <property name="position">1</property>
                                                      </packing>
                                                    </child>
                                                  </object>
                                                  <packing>
                                                    <property name="expand">False</property>
                                                    <property name="fill">True</property>
                                                    <property name="position">2</property>
                                                  </packing>
                                                </child>
                                              </object>
                                            </child>
                                          </object>
                                        </child>
                                        <child type="label">
                                          <object class="GtkLabel" id="label132">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="label" translatable="yes">&lt;b&gt;Filters&lt;/b&gt;</property>
                                            <property name="use_markup">True</property>
                                          </object>
                                        </child>
                                      </object>
                                      <packing>
                                        <property name="expand">False</property>
                                        <property name="fill">True</property>
                                        <property name="position">0</property>
                                      </packing>
                                    </child>
                                    <child>
                                      <object class="GtkVBox" id="vbox42">
                                        <property name="visible">True</property>
                                        <property name="can_focus">False</property>
                                        <child>
                                          <placeholder/>
                                        </child>
                                        <child>
                                          <object class="GtkHBox" id="hbox12">
                                            <property name="visible">True</property>
                                            <property name="can_focus">False</property>
                                            <property name="spacing">2</property>
                                            <child>
                                              <object class="GtkCheckButton" id="log_follow">
                                                <property name="label" translatable="yes">Follow</property>
                                                <property name="visible">True</property>
                                                <property name="can_focus">True</property>
                                                <property name="receives_default">False</property>
                                                <property name="tooltip_text" translatable="yes">Follow log updates by moving log view to the end.</property>
                                                <property name="use_action_appearance">False</property>
                                                <property name="active">True</property>
                                                <property name="draw_indicator">True</property>
                                              </object>
                                              <packing>
                                                <property name="expand">False</property>
                                                <property name="fill">True</property>
                                                <property name="position">0</property>
                                              </packing>
                                            </child>
                                            <child>
                                              <object class="GtkButton" id="copy_log">
                                                <property name="label">gtk-copy</property>
                                                <property name="visible">True</property>
                                                <property name="can_focus">True</property>
                                                <property name="receives_default">True</property>
                                                <property name="tooltip_text" translatable="yes">Copy log to clipboard.</property>
                                                <property name="use_action_appearance">False</property>
                                                <property name="use_stock">True</property>
                                                <signal name="clicked" handler="on_copy_log_clicked" swapped="no"/>
                                              </object>
                                              <packing>
                                                <property name="expand">False</property>
                                                <property name="fill">False</property>
                                                <property name="position">1</property>
                                              </packing>
                                            </child>
                                            <child>
                                              <object class="GtkButton" id="clear_log">
                                                <property name="label">gtk-clear</property>
                                                <property name="visible">True</property>
                                                <property name="can_focus">True</property>
                                                <property name="receives_default">True</property>
                                                <property name="tooltip_text" translatable="yes">Clear the log.</property>
                                                <property name="use_action_appearance">False</property>
                                                <property name="use_stock">True</property>
                                                <signal name="clicked" handler="on_clear_log_clicked" swapped="no"/>
                                              </object>
                                              <packing>
                                                <property name="expand">False</property>
                                                <property name="fill">False</property>
                                                <property name="position">2</property>
                                              </packing>
                                            </child>
                                            <child>
                                              <object class="GtkButton" id="download_log">
                                                <property name="label">gtk-refresh</property>
                                                <property name="visible">True</property>
                                                <property name="can_focus">True</property>
                                                <property name="receives_default">True</property>
                                                <property name="tooltip_text" translatable="yes">Reload all of the current log from the client.</property>
                                                <property name="use_action_appearance">False</property>
                                                <property name="use_stock">True</property>
                                                <signal name="clicked" handler="on_download_log_clicked" swapped="no"/>
                                              </object>
                                              <packing>
                                                <property name="expand">False</property>
                                                <property name="fill">False</property>
                                                <property name="position">3</property>
                                              </packing>
                                            </child>
                                          </object>
                                          <packing>
                                            <property name="expand">False</property>
                                            <property name="fill">False</property>
                                            <property name="pack_type">end</property>
                                            <property name="position">1</property>
                                          </packing>
                                        </child>
                                      </object>
                                      <packing>
                                        <property name="expand">True</property>
                                        <property name="fill">True</property>
                                        <property name="position">1</property>
                                      </packing>
                                    </child>
                                  </object>
                                  <packing>
                                    <property name="expand">False</property>
                                    <property name="fill">True</property>
                                    <property name="position">0</property>
                                  </packing>
                                </child>
                                <child>
                                  <object class="GtkScrolledWindow" id="scrolledwindow4">
                                    <property name="visible">True</property>
                                    <property name="can_focus">True</property>
                                    <property name="hscrollbar_policy">never</property>
                                    <property name="vscrollbar_policy">automatic</property>
                                    <property name="shadow_type">etched-in</property>
                                    <child>
                                      <object class="GtkTextView" id="log_text_view">
                                        <property name="visible">True</property>
                                        <property name="can_focus">True</property>
                                        <property name="editable">False</property>
                                        <property name="wrap_mode">word</property>
                                        <property name="indent">10</property>
                                        <property name="cursor_visible">False</property>
                                        <property name="buffer">log_buffer</property>
                                      </object>
                                    </child>
                                  </object>
                                  <packing>
                                    <property name="expand">True</property>
                                    <property name="fill">True</property>
                                    <property name="position">1</property>
                                  </packing>
                                </child>
                              </object>
                            </child>
                          </object>
                          <packing>
                            <property name="position">2</property>
                          </packing>
                        </child>
                        <child type="tab">
                          <object class="GtkLabel" id="log_tab_label">
                            <property name="visible">True</property>
                            <property name="can_focus">False</property>
                            <property name="label" translatable="yes">Log</property>
                          </object>
                          <packing>
                            <property name="position">2</property>
                            <property name="tab_fill">False</property>
                          </packing>
                        </child>
                      </object>
                    </child>
                  </object>
                </child>
                <child type="label">
                  <object class="GtkLabel" id="client_label">
                    <property name="visible">True</property>
                    <property name="can_focus">False</property>
                    <property name="label" translatable="yes">&lt;b&gt;Client: &lt;/b&gt;</property>
                    <property name="use_markup">True</property>
                  </object>
                </child>
              </object>
              <packing>
                <property name="resize">True</property>
                <property name="shrink">True</property>
              </packing>
            </child>
          </object>
          <packing>
            <property name="expand">True</property>
            <property name="fill">True</property>
            <property name="position">1</property>
          </packing>
        </child>
        <child>
          <object class="GtkStatusbar" id="status_bar">
            <property name="visible">True</property>
            <property name="can_focus">False</property>
            <property name="spacing">2</property>
            <child>
              <object class="GtkLabel" id="ppd_label">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="tooltip_text" translatable="yes">PPD is a smoothed estimate of total Points Per Day for all connected clients and slots.  It may slightly overestimate your points because it does not account for pauses between work units.</property>
                <property name="xalign">0</property>
                <property name="xpad">5</property>
              </object>
              <packing>
                <property name="expand">True</property>
                <property name="fill">True</property>
                <property name="position">0</property>
              </packing>
            </child>
            <child>
              <object class="GtkLabel" id="time_label">
                <property name="visible">True</property>
                <property name="can_focus">False</property>
                <property name="tooltip_text" translatable="yes">Current UTC time.</property>
                <property name="xalign">1</property>
                <property name="xpad">50</property>
              </object>
              <packing>
                <property name="expand">True</property>
                <property name="fill">True</property>
                <property name="pack_type">end</property>
                <property name="position">1</property>
              </packing>
            </child>
          </object>
          <packing>
            <property name="expand">False</property>
            <property name="fill">True</property>
            <property name="pack_type">end</property>
            <property name="position">2</property>
          </packing>
        </child>
      </object>
    </child>
  </object>
</interface>
"""
